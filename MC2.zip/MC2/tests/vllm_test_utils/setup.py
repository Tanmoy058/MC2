# SPDX-License-Identifier: Apache-2.0

from setuptools import setup

setup(
    name='vllm_test_utils',
    version='0.1',
    packages=['vllm_test_utils'],
)
