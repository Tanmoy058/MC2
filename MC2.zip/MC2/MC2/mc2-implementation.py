_value: Value to assign to the parameter
        
        Returns:
            Configured MC2System
        """
        model = self.create_dummy_model()
        
        # Default values
        block_size = 8
        reserved_blocks = 8
        alpha = 0.95
        beta = 0.001
        preallocate_iterations = 2
        
        # Override parameter
        if param_name == "block_size":
            block_size = param_value
        elif param_name == "reserved_blocks":
            reserved_blocks = param_value
        elif param_name == "preallocate_iterations":
            preallocate_iterations = param_value
        elif param_name == "confidence":
            alpha = param_value
        
        return MC2System(
            model=model,
            total_kvc_capacity=100000,
            block_size=block_size,
            reserved_blocks=reserved_blocks,
            alpha=alpha,
            beta=beta,
            preallocate_iterations=preallocate_iterations
        )
    
    def load_dataset(self, dataset_name, num_samples=50, slo_scale=1.0):
        """
        Load samples from a dataset with adjustable SLO scale
        
        Args:
            dataset_name: Name of the dataset
            num_samples: Number of samples to generate
            slo_scale: Scale factor for SLOs
        
        Returns:
            List of request data
        """
        # Dataset properties (same as before)
        if dataset_name == "Alpaca":
            avg_input_length = 19.31
            avg_output_length = 58.41
            min_input = 9
            max_input = 2470
            min_output = 13
            max_output = 292
        elif dataset_name == "ShareGPT":
            avg_input_length = 161.31
            avg_output_length = 337.99
            min_input = 16
            max_input = 3200
            min_output = 19
            max_output = 991
        elif dataset_name == "BookCorpus":
            avg_input_length = 1952.11
            avg_output_length = 681.2
            min_input = 18
            max_input = 461000
            min_output = 32
            max_output = 1041
        else:
            raise ValueError(f"Unknown dataset: {dataset_name}")
        
        # Generate samples
        samples = []
        for i in range(num_samples):
            # Generate lengths (same as before)
            input_length = int(np.random.lognormal(
                mean=np.log(avg_input_length), 
                sigma=0.5
            ))
            input_length = max(min_input, min(max_input, input_length))
            
            output_length = int(np.random.lognormal(
                mean=np.log(avg_output_length), 
                sigma=0.6
            ))
            output_length = max(min_output, min(max_output, output_length))
            
            prompt = " ".join(["token"] * input_length)
            
            # Apply SLO scale
            base_ttft_slo = random.uniform(0.5, 2.5) * (1 + input_length / 1000)
            base_tbt_slo = random.uniform(0.1, 0.5)
            
            ttft_slo = base_ttft_slo * slo_scale
            tbt_slo = base_tbt_slo * slo_scale
            
            samples.append({
                "id": f"{dataset_name}_{i}",
                "prompt": prompt,
                "input_length": input_length,
                "expected_output_length": output_length,
                "ttft_slo": ttft_slo,
                "tbt_slo": tbt_slo
            })
        
        return samples
    
    def run_sensitivity_analysis(self, arrival_rate=32, num_requests=50):
        """
        Run sensitivity analysis for all parameters
        
        Args:
            arrival_rate: Request arrival rate to test
            num_requests: Number of requests to simulate
        """
        for param_name, param_values in self.parameters.items():
            print(f"Analyzing sensitivity to {param_name}...")
            
            for dataset in self.datasets:
                print(f"  Dataset: {dataset}")
                
                # Adjust arrival rate for the dataset
                if dataset == "BookCorpus":
                    dataset_rate = min(arrival_rate, 1.2)
                else:
                    dataset_rate = arrival_rate
                
                for param_value in tqdm(param_values, desc=f"{param_name} values"):
                    # Special case for SLO scale
                    if param_name == "slo_scale":
                        # Load dataset with adjusted SLO scale
                        requests = self.load_dataset(dataset, num_requests, param_value)
                        system = self.create_mc2_system(None, None)  # Default parameters
                    else:
                        # Load dataset with default SLO scale
                        requests = self.load_dataset(dataset, num_requests)
                        system = self.create_mc2_system(param_name, param_value)
                    
                    # Simulate request processing
                    metrics = self.simulate_requests(system, requests, dataset_rate)
                    
                    # Store results
                    for metric in self.metrics:
                        self.results[dataset][param_name][metric][param_value] = metrics[metric]
    
    def simulate_requests(self, system, requests, arrival_rate):
        """Simulate request processing (similar to previous implementations)"""
        current_time = 0.0
        active_requests = []
        completed_requests = []
        
        # Metrics to track
        ttft_values = []
        tbt_values = []
        ttft_slo_met = 0
        tbt_slo_met = 0
        
        # Add requests according to arrival rate
        for request in requests:
            # Get interarrival time
            interarrival = np.random.exponential(1.0 / arrival_rate)
            current_time += interarrival
            
            # Add request
            request_id = system.add_request(
                prompt=request["prompt"],
                ttft_slo=request["ttft_slo"],
                tbt_slo=request["tbt_slo"]
            )
            
            # Store request data
            if request_id in system.active_requests:
                system.active_requests[request_id].arrival_time = current_time
                system.active_requests[request_id].expected_output_length = request["expected_output_length"]
                system.active_requests[request_id].input_id = request["id"]
                active_requests.append(request_id)
            
            # Run iterations
            num_iterations = max(1, int(interarrival / 0.1))
            
            for _ in range(num_iterations):
                system.run_iteration()
                
                # Update metrics for completed requests
                self.update_metrics(
                    system, active_requests, completed_requests,
                    ttft_values, tbt_values, ttft_slo_met, tbt_slo_met
                )
        
        # Complete any remaining requests
        while active_requests:
            system.run_iteration()
            
            # Update metrics
            ttft_slo_met, tbt_slo_met = self.update_metrics(
                system, active_requests, completed_requests,
                ttft_values, tbt_values, ttft_slo_met, tbt_slo_met
            )
        
        # Calculate final metrics
        if ttft_values:
            ttft_slo_attainment = ttft_slo_met / len(ttft_values)
        else:
            ttft_slo_attainment = 0
        
        if tbt_values:
            tbt_slo_attainment = tbt_slo_met / len(tbt_values)
        else:
            tbt_slo_attainment = 0
        
        return {
            "ttft_slo_attainment": ttft_slo_attainment,
            "tbt_slo_attainment": tbt_slo_attainment,
            "num_completed": len(completed_requests),
            "total_time": current_time
        }
    
    def update_metrics(self, system, active_requests, completed_requests, 
                      ttft_values, tbt_values, ttft_slo_met, tbt_slo_met):
        """Update metrics for completed requests"""
        for req_id in list(system.completed_requests.keys()):
            if req_id in active_requests:
                active_requests.remove(req_id)
                
                request = system.completed_requests[req_id]
                
                # Calculate TTFT
                ttft = request.first_token_time - request.arrival_time if hasattr(request, 'first_token_time') else 0.5
                ttft_values.append(ttft)
                
                # Calculate TBT
                tbt = request.average_token_time if hasattr(request, 'average_token_time') else 0.1
                tbt_values.append(tbt)
                
                # Check SLO attainment
                if ttft <= request.ttft_slo:
                    ttft_slo_met += 1
                
                if tbt <= request.tbt_slo:
                    tbt_slo_met += 1
                
                completed_requests.append(req_id)
        
        return ttft_slo_met, tbt_slo_met
    
    def plot_results(self, output_dir="./plots/sensitivity"):
        """
        Plot the sensitivity analysis results
        
        Args:
            output_dir: Directory to save plots
        """
        import os
        os.makedirs(output_dir, exist_ok=True)
        
        # Plot for each dataset, parameter, and metric
        for dataset in self.datasets:
            for param_name, param_data in self.results[dataset].items():
                # Create figure
                plt.figure(figsize=(10, 6))
                
                # Plot each metric
                for metric, values in param_data.items():
                    # Sort by parameter value
                    param_values = sorted(values.keys())
                    metric_values = [values[param] for param in param_values]
                    
                    plt.plot(param_values, metric_values, marker='o', label=metric.replace('_', ' ').title())
                
                # Set labels and title
                plt.xlabel(param_name.replace('_', ' ').title())
                plt.ylabel("SLO Attainment")
                plt.title(f"Sensitivity to {param_name.replace('_', ' ').title()} - {dataset}")
                
                plt.legend()
                plt.grid(True, alpha=0.3)
                
                # Save plot
                plt.savefig(os.path.join(output_dir, f"{dataset}_{param_name}.png"))
                plt.close()
    
    def generate_report(self, output_file="mc2_sensitivity_analysis.md"):
        """
        Generate a sensitivity analysis report
        
        Args:
            output_file: File to save the report
        """
        with open(output_file, "w") as f:
            f.write("# MC2 Sensitivity Analysis\n\n")
            
            f.write("This report presents the results of a sensitivity analysis conducted on the MC2 system, "
                    "evaluating how different parameter values affect performance.\n\n")
            
            for dataset in self.datasets:
                f.write(f"## {dataset} Dataset\n\n")
                
                for param_name, param_data in self.results[dataset].items():
                    f.write(f"### Sensitivity to {param_name.replace('_', ' ').title()}\n\n")
                    
                    # Table header
                    f.write(f"| {param_name.title()} |")
                    for metric in self.metrics:
                        f.write(f" {metric.replace('_', ' ').title()} |")
                    f.write("\n")
                    
                    # Add separator row
                    f.write("|")
                    for _ in range(len(self.metrics) + 1):
                        f.write(" --- |")
                    f.write("\n")
                    
                    # Sort parameter values
                    param_values = sorted(next(iter(param_data.values())).keys())
                    
                    # Add data rows
                    for param_value in param_values:
                        f.write(f"| {param_value} |")
                        for metric in self.metrics:
                            value = param_data[metric].get(param_value, 0)
                            f.write(f" {value:.2f} |")
                        f.write("\n")
                    
                    f.write("\n")
                    
                    # Add analysis
                    f.write("#### Analysis\n\n")
                    
                    for metric in self.metrics:
                        metric_values = param_data[metric]
                        param_values = sorted(metric_values.keys())
                        values = [metric_values[param] for param in param_values]
                        
                        if values:
                            # Find optimal value
                            optimal_idx = values.index(max(values))
                            optimal_param = param_values[optimal_idx]
                            
                            f.write(f"For {metric.replace('_', ' ')}, the optimal {param_name.replace('_', ' ')} "
                                    f"value appears to be **{optimal_param}**, achieving an SLO attainment of {values[optimal_idx]:.2f}.\n\n")
                            
                            # Sensitivity analysis
                            if len(values) > 1:
                                min_val = min(values)
                                max_val = max(values)
                                range_pct = (max_val - min_val) / max_val * 100 if max_val > 0 else 0
                                
                                if range_pct > 20:
                                    sensitivity = "highly sensitive"
                                elif range_pct > 10:
                                    sensitivity = "moderately sensitive"
                                else:
                                    sensitivity = "not very sensitive"
                                
                                f.write(f"MC2's {metric.replace('_', ' ')} is {sensitivity} to changes in {param_name.replace('_', ' ')}, "
                                        f"with performance varying by {range_pct:.1f}% across the tested range.\n\n")
                
                f.write("---\n\n")
            
            # Overall recommendations
            f.write("## Parameter Recommendations\n\n")
            
            for param_name in self.parameters:
                f.write(f"### {param_name.replace('_', ' ').title()}\n\n")
                
                optimal_values = []
                for dataset in self.datasets:
                    for metric in self.metrics:
                        if dataset in self.results and param_name in self.results[dataset] and metric in self.results[dataset][param_name]:
                            metric_values = self.results[dataset][param_name][metric]
                            param_values = sorted(metric_values.keys())
                            values = [metric_values[param] for param in param_values]
                            
                            if values:
                                optimal_idx = values.index(max(values))
                                optimal_param = param_values[optimal_idx]
                                optimal_values.append((optimal_param, dataset, metric))
                
                if optimal_values:
                    # Count occurrences of each value
                    value_counts = defaultdict(int)
                    for val, _, _ in optimal_values:
                        value_counts[val] += 1
                    
                    # Find most common value
                    recommended_value, count = max(value_counts.items(), key=lambda x: x[1])
                    
                    f.write(f"**Recommended value**: {recommended_value}\n\n")
                    f.write(f"This value was optimal in {count} out of {len(optimal_values)} test cases.\n\n")
                    
                    # List all optimal values
                    f.write("Optimal values by dataset and metric:\n\n")
                    for val, ds, met in optimal_values:
                        f.write(f"- {ds}, {met.replace('_', ' ')}: {val}\n")
                    
                    f.write("\n")


##############################################
# 8. Example Usage and Main Function
##############################################

def example_usage():
    """Example usage of the MC2 system"""
    # Simulate a model (in a real implementation, this would be a vLLM model)
    class DummyModel:
        def __init__(self):
            self.config = type('obj', (object,), {'hidden_size': 1024})
    
    dummy_model = DummyModel()
    
    # Create MC2 system
    mc2 = MC2System(
        model=dummy_model,
        total_kvc_capacity=100000,  # 100K tokens
        block_size=8,
        reserved_blocks=8,
        alpha=0.95,
        beta=0.001,
        preallocate_iterations=2
    )
    
    # Add some requests with varying SLOs
    request_ids = []
    
    # Request with tight SLOs
    request_ids.append(mc2.add_request(
        prompt="Generate a short story about AI serving systems",
        ttft_slo=0.5,  # 500ms for first token
        tbt_slo=0.1    # 100ms between tokens
    ))
    
    # Request with loose SLOs
    request_ids.append(mc2.add_request(
        prompt="Explain the history of artificial intelligence in great detail",
        ttft_slo=2.0,   # 2s for first token
        tbt_slo=0.5     # 500ms between tokens
    ))
    
    # Run multiple iterations
    for i in range(20):
        logger.info(f"Running iteration {i}...")
        stats = mc2.run_iteration()
        logger.info(f"Iteration stats: {stats}")
        
        # Print status of all requests
        for req_id in request_ids:
            status = mc2.get_request_status(req_id)
            logger.info(f"Request {req_id} status: {status}")
        
        # Sleep to simulate time passing between iterations
        time.sleep(0.1)
    
    logger.info("Simulation complete")


def main():
    """Main function to run the MC2 implementation"""
    parser = argparse.ArgumentParser(description="MC2: Mitigating KV Cache Competition for LLM Serving")
    parser.add_argument("--mode", type=str, default="example", 
                        choices=["example", "evaluate", "ablation", "sensitivity"],
                        help="Mode to run (example, evaluate, ablation, sensitivity)")
    parser.add_argument("--vllm_path", type=str, default=None,
                        help="Path to vLLM installation (for patching)")
    parser.add_argument("--output_dir", type=str, default="./results",
                        help="Directory to save results")
    
    args = parser.parse_args()
    
    # Create output directory
    os.makedirs(args.output_dir, exist_ok=True)
    
    if args.mode == "example":
        # Run example usage
        print("Running MC2 example usage...")
        example_usage()
    
    elif args.mode == "evaluate":
        # Run performance evaluation
        print("Running MC2 performance evaluation...")
        evaluator = PerformanceEvaluator()
        
        # Run evaluations with multiple arrival rates
        arrival_rates = [4, 8, 16, 24, 28, 32, 36, 40]
        evaluator.run_evaluations(arrival_rates, num_requests=100)
        
        # Generate plots and report
        evaluator.plot_results(os.path.join(args.output_dir, "plots"))
        evaluator.generate_report(os.path.join(args.output_dir, "mc2_evaluation_results.md"))
        evaluator.save_results(os.path.join(args.output_dir, "mc2_evaluation_results.json"))
        
        print(f"Evaluation results saved to {args.output_dir}")
    
    elif args.mode == "ablation":
        # Run ablation study
        print("Running MC2 ablation study...")
        ablation = AblationStudy()
        
        # Run ablation study
        ablation.run_ablation_study(arrival_rate=32, num_requests=100)
        
        # Generate plots and report
        ablation.plot_results(os.path.join(args.output_dir, "plots/ablation"))
        ablation.generate_report(os.path.join(args.output_dir, "mc2_ablation_study.md"))
        
        print(f"Ablation study results saved to {args.output_dir}")
    
    elif args.mode == "sensitivity":
        # Run sensitivity analysis
        print("Running MC2 sensitivity analysis...")
        sensitivity = SensitivityAnalysis()
        
        # Run sensitivity analysis
        sensitivity.run_sensitivity_analysis(arrival_rate=32, num_requests=50)
        
        # Generate plots and report
        sensitivity.plot_results(os.path.join(args.output_dir, "plots/sensitivity"))
        sensitivity.generate_report(os.path.join(args.output_dir, "mc2_sensitivity_analysis.md"))
        
        print(f"Sensitivity analysis results saved to {args.output_dir}")
    
    # Patch vLLM if path provided
    if args.vllm_path:
        print(f"Patching vLLM at {args.vllm_path}...")
        
        # Patch scheduler
        patch_success = patch_vllm_scheduler(args.vllm_path)
        if patch_success:
            print("Successfully patched vLLM scheduler")
        else:
            print("Failed to patch vLLM scheduler")
        
        # Patch kvcache
        patch_success = patch_vllm_kvcache(args.vllm_path)
        if patch_success:
            print("Successfully patched vLLM kvcache")
        else:
            print("Failed to patch vLLM kvcache")


if __name__ == "__main__":
    main()
                    f.write("|")
                    for _ in range(len(systems) + 1):
                        f.write(" --- |")
                    f.write("\n")
                    
                    # Add data rows
                    for rate in arrival_rates:
                        f.write(f"| {rate} |")
                        for system in systems:
                            value = metric_data.get((system, rate), 0)
                            if "attainment" in metric:
                                f.write(f" {value:.2f} |")
                            else:
                                f.write(f" {value:.3f} |")
                        f.write("\n")
                    f.write("\n")
                
                # Add performance comparison
                f.write("### Performance Comparison\n\n")
                
                for metric in self.metrics:
                    f.write(f"#### {metric.replace('_', ' ').title()}\n\n")
                    
                    # Calculate improvements
                    metric_data = self.results[dataset][metric]
                    arrival_rates = sorted(set(rate for _, rate in metric_data.keys()))
                    
                    for rate in arrival_rates:
                        mc2_value = metric_data.get(("MC2", rate), 0)
                        
                        improvements = []
                        for system in [s for s in systems if s != "MC2"]:
                            system_value = metric_data.get((system, rate), 0)
                            
                            if system_value > 0:
                                if "attainment" in metric:
                                    # Higher is better
                                    improvement = (mc2_value / system_value - 1) * 100
                                else:
                                    # Lower is better
                                    improvement = (1 - mc2_value / system_value) * 100
                                
                                improvements.append((system, improvement))
                        
                        if improvements:
                            f.write(f"At arrival rate {rate} req/s:\n\n")
                            for system, improvement in improvements:
                                if improvement > 0:
                                    f.write(f"- MC2 {('improves on' if 'attainment' in metric else 'reduces')} {system}'s {metric.replace('_', ' ')} by {abs(improvement):.1f}%\n")
                                else:
                                    f.write(f"- MC2 {('performs worse than' if 'attainment' in metric else 'increases')} {system}'s {metric.replace('_', ' ')} by {abs(improvement):.1f}%\n")
                            f.write("\n")
                
                f.write("---\n\n")
            
            # Overall summary
            f.write("## Overall Summary\n\n")
            f.write("Based on the performance evaluation results, MC2 demonstrates significant improvements:\n\n")
            
            # Calculate average improvements
            improvements = defaultdict(list)
            
            for dataset in self.datasets:
                for metric in self.metrics:
                    metric_data = self.results[dataset][metric]
                    arrival_rates = sorted(set(rate for _, rate in metric_data.keys()))
                    
                    for rate in arrival_rates:
                        mc2_value = metric_data.get(("MC2", rate), 0)
                        
                        for system in [s for s in systems if s != "MC2"]:
                            system_value = metric_data.get((system, rate), 0)
                            
                            if system_value > 0:
                                if "attainment" in metric:
                                    # Higher is better
                                    improvement = (mc2_value / system_value - 1) * 100
                                else:
                                    # Lower is better
                                    improvement = (1 - mc2_value / system_value) * 100
                                
                                improvements[(system, metric)].append(improvement)
            
            # Report average improvements
            for (system, metric), vals in improvements.items():
                avg_improvement = sum(vals) / len(vals)
                f.write(f"- MC2 {('improves on' if 'attainment' in metric else 'reduces')} {system}'s {metric.replace('_', ' ')} by an average of {abs(avg_improvement):.1f}%\n")
            
            f.write("\n")
            f.write("MC2's key advantages come from its novel components:\n\n")
            f.write("1. **Confidence-based Padding**: Adjusts padding based on statistical confidence and arrival rate\n")
            f.write("2. **SLO-aware Batching and KVC Allocation**: Prioritizes critical requests and reuses KVC efficiently\n")
            f.write("3. **Improved Preemption Policy**: Selects requests for preemption based on SLOs, remaining time, and KVC usage\n")
            f.write("4. **Smart Preemption Strategy Selection**: Dynamically chooses between swapping and recomputation\n\n")
            
            f.write("These components together enable MC2 to achieve significantly better TTFT and TBT, higher SLO attainments, and support higher request arrival rates.")
    
    def save_results(self, output_file="mc2_evaluation_results.json"):
        """
        Save the raw results to a JSON file
        
        Args:
            output_file: File to save the results
        """
        # Prepare results for JSON serialization
        serializable_results = {}
        
        for dataset in self.datasets:
            serializable_results[dataset] = {}
            
            for metric in self.metrics:
                serializable_results[dataset][metric] = {}
                
                for (system, rate), value in self.results[dataset][metric].items():
                    serializable_results[dataset][metric][f"{system}_{rate}"] = value
        
        # Save to file
        with open(output_file, "w") as f:
            json.dump(serializable_results, f, indent=2)


##############################################
# 6. Ablation Study
##############################################

class AblationStudy:
    """Evaluate the contribution of individual MC2 components"""
    
    def __init__(self, datasets=None):
        """
        Initialize the ablation study
        
        Args:
            datasets: List of datasets to evaluate
        """
        self.datasets = datasets or ["Alpaca", "ShareGPT", "BookCorpus"]
        self.metrics = ["tail_ttft", "ttft_slo_attainment", "tail_tbt", "tbt_slo_attainment"]
        
        # Variants to test
        self.variants = [
            "MC2",  # Full system
            "/CKA",  # Without Confident-based KVC Allocation
            "/RSA",  # Without Request Selection and KVC Allocation
            "/PA",   # Without Proactive KVC allocation
            "/GR",   # Without Global Reservation
            "/PP",   # Without Preemption Policy
            "/PSS"   # Without Preemption Strategy Selection
        ]
        
        # Results storage
        self.results = defaultdict(lambda: defaultdict(dict))
    
    def create_variant(self, variant_type, model):
        """
        Create a variant of the MC2 system
        
        Args:
            variant_type: Type of variant to create
            model: Base model
        
        Returns:
            MC2System with the specified configuration
        """
        if variant_type == "MC2":
            # Full MC2 system
            return MC2System(
                model=model,
                total_kvc_capacity=100000,
                block_size=8,
                reserved_blocks=8,
                alpha=0.95,
                beta=0.001,
                preallocate_iterations=2
            )
        
        elif variant_type == "/CKA":
            # Without Confident-based KVC Allocation
            system = MC2System(
                model=model,
                total_kvc_capacity=100000,
                block_size=8,
                reserved_blocks=8,
                alpha=0.95,
                beta=0.001,
                preallocate_iterations=2
            )
            
            # Override padding calculation to use fixed padding
            def fixed_padding(predicted_length, *args, **kwargs):
                return int(predicted_length * 0.1)  # 10% of predicted length
            
            system.padding_calculator.calculate_padding = fixed_padding
            return system
        
        elif variant_type == "/RSA":
            # Without Request Selection and KVC Allocation
            system = MC2System(
                model=model,
                total_kvc_capacity=100000,
                block_size=8,
                reserved_blocks=8,
                alpha=0.95,
                beta=0.001,
                preallocate_iterations=2
            )
            
            # Override batch formation to use FCFS
            original_form_batch = system.scheduler.form_next_batch
            
            def fcfs_batch_formation():
                # Simplified FCFS batch formation
                batch = []
                available_kvc = system.kvc_manager.available_kvc
                
                # Add requests in FCFS order until KVC is exhausted
                for req in system.scheduler.waiting_queue[:]:
                    kvc_needed = req.prompt_length + req.estimated_output_length
                    
                    if kvc_needed <= available_kvc:
                        batch.append(req)
                        system.scheduler.waiting_queue.remove(req)
                        available_kvc -= kvc_needed
                    
                # Update running requests
                system.scheduler.running_requests.extend(batch)
                return batch
            
            system.scheduler.form_next_batch = fcfs_batch_formation
            return system
        
        elif variant_type == "/PA":
            # Without Proactive KVC allocation
            return MC2System(
                model=model,
                total_kvc_capacity=100000,
                block_size=8,
                reserved_blocks=8,
                alpha=0.95,
                beta=0.001,
                preallocate_iterations=0  # Disable proactive allocation
            )
        
        elif variant_type == "/GR":
            # Without Global Reservation
            return MC2System(
                model=model,
                total_kvc_capacity=100000,
                block_size=8,
                reserved_blocks=0,  # Disable global reservation
                alpha=0.95,
                beta=0.001,
                preallocate_iterations=2
            )
        
        elif variant_type == "/PP":
            # Without Preemption Policy (use FCFS)
            system = MC2System(
                model=model,
                total_kvc_capacity=100000,
                block_size=8,
                reserved_blocks=8,
                alpha=0.95,
                beta=0.001,
                preallocate_iterations=2
            )
            
            # Override preemption policy to use FCFS
            def fcfs_preemption(_):
                # Take the most recently added request
                if system.scheduler.running_requests:
                    return system.scheduler.running_requests[-1]
                return None
            
            system.scheduler.select_request_for_preemption = fcfs_preemption
            return system
        
        elif variant_type == "/PSS":
            # Without Preemption Strategy Selection (always use recomputation)
            system = MC2System(
                model=model,
                total_kvc_capacity=100000,
                block_size=8,
                reserved_blocks=8,
                alpha=0.95,
                beta=0.001,
                preallocate_iterations=2
            )
            
            # Override preemption strategy selection to always use recomputation
            system.scheduler.select_preemption_strategy = lambda _: "recompute"
            return system
        
        else:
            raise ValueError(f"Unknown variant type: {variant_type}")
    
    def run_ablation_study(self, arrival_rate=32, num_requests=100):
        """
        Run the ablation study
        
        Args:
            arrival_rate: Request arrival rate to test
            num_requests: Number of requests to simulate
        """
        # Create dummy model
        class DummyModel:
            def __init__(self):
                self.config = type('obj', (object,), {'hidden_size': 1024})
        
        model = DummyModel()
        
        for dataset in self.datasets:
            print(f"Running ablation study on {dataset} dataset...")
            
            # Adjust arrival rate for the dataset
            if dataset == "BookCorpus":
                dataset_rate = min(arrival_rate, 1.2)  # Much lower rate for BookCorpus
            else:
                dataset_rate = arrival_rate
            
            for variant in tqdm(self.variants, desc="Variants"):
                # Create system variant
                system = self.create_variant(variant, model)
                
                # Load dataset
                samples = self.load_dataset(dataset, num_requests)
                
                # Simulate request processing
                metrics = self.simulate_requests(system, samples, dataset_rate)
                
                # Store results
                for metric in self.metrics:
                    self.results[dataset][metric][variant] = metrics[metric]
                
                print(f"  {variant}: TTFT SLO attainment = {metrics['ttft_slo_attainment']:.2f}, "
                      f"TBT SLO attainment = {metrics['tbt_slo_attainment']:.2f}")
    
    def load_dataset(self, dataset_name, num_samples=100):
        """Load samples from a dataset (similar to PerformanceEvaluator)"""
        if dataset_name == "Alpaca":
            avg_input_length = 19.31
            avg_output_length = 58.41
            min_input = 9
            max_input = 2470
            min_output = 13
            max_output = 292
        elif dataset_name == "ShareGPT":
            avg_input_length = 161.31
            avg_output_length = 337.99
            min_input = 16
            max_input = 3200
            min_output = 19
            max_output = 991
        elif dataset_name == "BookCorpus":
            avg_input_length = 1952.11
            avg_output_length = 681.2
            min_input = 18
            max_input = 461000
            min_output = 32
            max_output = 1041
        else:
            raise ValueError(f"Unknown dataset: {dataset_name}")
        
        # Generate samples with length distributions matching the datasets
        samples = []
        for i in range(num_samples):
            input_length = int(np.random.lognormal(
                mean=np.log(avg_input_length), 
                sigma=0.5
            ))
            input_length = max(min_input, min(max_input, input_length))
            
            output_length = int(np.random.lognormal(
                mean=np.log(avg_output_length), 
                sigma=0.6
            ))
            output_length = max(min_output, min(max_output, output_length))
            
            # Create a dummy prompt with the right length
            prompt = " ".join(["token"] * input_length)
            
            # Randomly assign SLOs
            ttft_slo = random.uniform(0.5, 2.5) * (1 + input_length / 1000)
            tbt_slo = random.uniform(0.1, 0.5)
            
            samples.append({
                "id": f"{dataset_name}_{i}",
                "prompt": prompt,
                "input_length": input_length,
                "expected_output_length": output_length,
                "ttft_slo": ttft_slo,
                "tbt_slo": tbt_slo
            })
        
        return samples
    
    def simulate_requests(self, system, requests, arrival_rate):
        """Simulate request processing (simplified from PerformanceEvaluator)"""
        current_time = 0.0
        active_requests = []
        completed_requests = []
        
        # Metrics to track
        ttft_values = []
        tbt_values = []
        ttft_slo_met = 0
        tbt_slo_met = 0
        
        # Add requests according to arrival rate
        for request in requests:
            # Get interarrival time from exponential distribution
            interarrival = np.random.exponential(1.0 / arrival_rate)
            current_time += interarrival
            
            # Add request with simulated arrival time
            request_id = system.add_request(
                prompt=request["prompt"],
                ttft_slo=request["ttft_slo"],
                tbt_slo=request["tbt_slo"]
            )
            
            # Store original request data
            if request_id in system.active_requests:
                system.active_requests[request_id].arrival_time = current_time
                system.active_requests[request_id].expected_output_length = request["expected_output_length"]
                system.active_requests[request_id].input_id = request["id"]
                active_requests.append(request_id)
            
            # Simulate serving system iterations
            num_iterations = max(1, int(interarrival / 0.1))
            
            for _ in range(num_iterations):
                system.run_iteration()
                
                # Update metrics for completed requests
                for req_id in list(system.completed_requests.keys()):
                    if req_id in active_requests:
                        active_requests.remove(req_id)
                        
                        request = system.completed_requests[req_id]
                        
                        # Calculate TTFT
                        ttft = request.first_token_time - request.arrival_time if hasattr(request, 'first_token_time') else 0.5
                        ttft_values.append(ttft)
                        
                        # Calculate TBT
                        tbt = request.average_token_time if hasattr(request, 'average_token_time') else 0.1
                        tbt_values.append(tbt)
                        
                        # Check SLO attainment
                        if ttft <= request.ttft_slo:
                            ttft_slo_met += 1
                        
                        if tbt <= request.tbt_slo:
                            tbt_slo_met += 1
                        
                        completed_requests.append(req_id)
        
        # Complete any remaining requests
        while active_requests:
            system.run_iteration()
            
            # Update metrics
            for req_id in list(system.completed_requests.keys()):
                if req_id in active_requests:
                    active_requests.remove(req_id)
                    
                    request = system.completed_requests[req_id]
                    
                    # Calculate metrics (same as above)
                    ttft = request.first_token_time - request.arrival_time if hasattr(request, 'first_token_time') else 0.5
                    ttft_values.append(ttft)
                    
                    tbt = request.average_token_time if hasattr(request, 'average_token_time') else 0.1
                    tbt_values.append(tbt)
                    
                    if ttft <= request.ttft_slo:
                        ttft_slo_met += 1
                    
                    if tbt <= request.tbt_slo:
                        tbt_slo_met += 1
                    
                    completed_requests.append(req_id)
        
        # Calculate metrics
        if ttft_values:
            tail_ttft = np.percentile(ttft_values, 95)
            ttft_slo_attainment = ttft_slo_met / len(ttft_values)
        else:
            tail_ttft = 0
            ttft_slo_attainment = 0
        
        if tbt_values:
            tail_tbt = np.percentile(tbt_values, 95)
            tbt_slo_attainment = tbt_slo_met / len(tbt_values)
        else:
            tail_tbt = 0
            tbt_slo_attainment = 0
        
        return {
            "tail_ttft": tail_ttft,
            "ttft_slo_attainment": ttft_slo_attainment,
            "tail_tbt": tail_tbt,
            "tbt_slo_attainment": tbt_slo_attainment,
            "num_completed": len(completed_requests),
            "total_time": current_time
        }
    
    def plot_results(self, output_dir="./plots/ablation"):
        """
        Plot the ablation study results
        
        Args:
            output_dir: Directory to save plots
        """
        import os
        os.makedirs(output_dir, exist_ok=True)
        
        # Plot for each dataset and metric
        for dataset in self.datasets:
            plt.figure(figsize=(12, 8))
            
            # Create subplots for each metric
            fig, axes = plt.subplots(2, 2, figsize=(15, 10))
            fig.suptitle(f"Ablation Study - {dataset}", fontsize=16)
            
            for i, metric in enumerate(self.metrics):
                ax = axes[i // 2, i % 2]
                
                # Get data
                values = [self.results[dataset][metric].get(variant, 0) for variant in self.variants]
                
                # Create bar plot
                bars = ax.bar(self.variants, values)
                
                # Add reference line for MC2 (full system)
                mc2_value = values[0]
                ax.axhline(y=mc2_value, color='r', linestyle='--', alpha=0.5)
                
                # Set title and labels
                ax.set_title(metric.replace('_', ' ').title())
                ax.set_ylabel("Value")
                ax.set_xlabel("System Variant")
                
                # Rotate x-axis labels
                plt.setp(ax.get_xticklabels(), rotation=45, ha="right", rotation_mode="anchor")
                
                # Add value labels
                for bar in bars:
                    height = bar.get_height()
                    ax.annotate(f"{height:.2f}",
                                xy=(bar.get_x() + bar.get_width() / 2, height),
                                xytext=(0, 3),
                                textcoords="offset points",
                                ha='center', va='bottom',
                                fontsize=8)
            
            plt.tight_layout(rect=[0, 0, 1, 0.96])
            plt.savefig(os.path.join(output_dir, f"{dataset}_ablation.png"))
            plt.close()
    
    def generate_report(self, output_file="mc2_ablation_study.md"):
        """
        Generate an ablation study report
        
        Args:
            output_file: File to save the report
        """
        with open(output_file, "w") as f:
            f.write("# MC2 Ablation Study Results\n\n")
            
            f.write("This report presents the results of an ablation study conducted on the MC2 system, "
                    "evaluating the contribution of each component to the overall performance.\n\n")
            
            f.write("## Variants Tested\n\n")
            f.write("- **MC2**: The full MC2 system with all components\n")
            f.write("- **/CKA**: MC2 without Confidence-based KVC Allocation\n")
            f.write("- **/RSA**: MC2 without Request Selection and KVC Allocation\n")
            f.write("- **/PA**: MC2 without Proactive KVC Allocation\n")
            f.write("- **/GR**: MC2 without Global Reservation\n")
            f.write("- **/PP**: MC2 without the advanced Preemption Policy\n")
            f.write("- **/PSS**: MC2 without Preemption Strategy Selection\n\n")
            
            for dataset in self.datasets:
                f.write(f"## {dataset} Dataset\n\n")
                
                # Generate tables for each metric
                for metric in self.metrics:
                    f.write(f"### {metric.replace('_', ' ').title()}\n\n")
                    
                    # Table header
                    f.write("| System Variant | Value | % Difference from MC2 |\n")
                    f.write("|---------------|-------|----------------------|\n")
                    
                    # Get MC2 (full system) value
                    mc2_value = self.results[dataset][metric].get("MC2", 0)
                    
                    # Add data rows
                    for variant in self.variants:
                        value = self.results[dataset][metric].get(variant, 0)
                        
                        if mc2_value > 0:
                            if "attainment" in metric:
                                # Higher is better
                                diff_pct = (value / mc2_value - 1) * 100
                            else:
                                # Lower is better
                                diff_pct = (1 - value / mc2_value) * 100
                        else:
                            diff_pct = 0
                        
                        f.write(f"| {variant} | {value:.3f} | {diff_pct:+.1f}% |\n")
                    
                    f.write("\n")
                
                # Summary of findings
                f.write("### Summary of Findings\n\n")
                
                f.write("Based on the ablation study results for the " + dataset + " dataset:\n\n")
                
                # For each component, analyze its impact
                components = [
                    ("/CKA", "Confidence-based KVC Allocation"),
                    ("/RSA", "Request Selection and KVC Allocation"),
                    ("/PA", "Proactive KVC Allocation"),
                    ("/GR", "Global Reservation"),
                    ("/PP", "Advanced Preemption Policy"),
                    ("/PSS", "Preemption Strategy Selection")
                ]
                
                for variant, component_name in components:
                    impacts = []
                    
                    for metric in self.metrics:
                        mc2_value = self.results[dataset][metric].get("MC2", 0)
                        variant_value = self.results[dataset][metric].get(variant, 0)
                        
                        if mc2_value > 0:
                            if "attainment" in metric:
                                # Higher is better
                                impact = (mc2_value / variant_value - 1) * 100
                                direction = "improvement"
                            else:
                                # Lower is better
                                impact = (1 - mc2_value / variant_value) * 100
                                direction = "reduction"
                            
                            impacts.append((metric, impact, direction))
                    
                    if impacts:
                        f.write(f"**{component_name}**:\n\n")
                        
                        for metric, impact, direction in impacts:
                            metric_name = metric.replace('_', ' ')
                            f.write(f"- {impact:+.1f}% {direction} in {metric_name}\n")
                        
                        f.write("\n")
                
                f.write("---\n\n")
            
            # Overall conclusions
            f.write("## Overall Conclusions\n\n")
            
            f.write("The ablation study demonstrates the importance of each component in the MC2 system:\n\n")
            
            # Calculate average impact of each component
            component_impacts = defaultdict(lambda: defaultdict(list))
            
            for dataset in self.datasets:
                for variant, component_name in components:
                    for metric in self.metrics:
                        mc2_value = self.results[dataset][metric].get("MC2", 0)
                        variant_value = self.results[dataset][metric].get(variant, 0)
                        
                        if mc2_value > 0 and variant_value > 0:
                            if "attainment" in metric:
                                # Higher is better
                                impact = (mc2_value / variant_value - 1) * 100
                            else:
                                # Lower is better
                                impact = (1 - mc2_value / variant_value) * 100
                            
                            component_impacts[component_name][metric].append(impact)
            
            # Report average impact for each component
            for component_name, metrics in component_impacts.items():
                f.write(f"**{component_name}**:\n\n")
                
                for metric, impacts in metrics.items():
                    if impacts:
                        avg_impact = sum(impacts) / len(impacts)
                        metric_name = metric.replace('_', ' ')
                        direction = "improvement" if "attainment" in metric else "reduction"
                        
                        f.write(f"- {avg_impact:.1f}% average {direction} in {metric_name}\n")
                
                f.write("\n")
            
            f.write("The results confirm that all components contribute to MC2's performance improvements, with the most significant impacts coming from:\n\n")
            
            # Identify most important components
            component_avg_impacts = {}
            for component_name, metrics in component_impacts.items():
                all_impacts = []
                for impacts in metrics.values():
                    all_impacts.extend(impacts)
                
                if all_impacts:
                    component_avg_impacts[component_name] = sum(all_impacts) / len(all_impacts)
            
            # Sort components by impact
            sorted_components = sorted(
                component_avg_impacts.items(), 
                key=lambda x: abs(x[1]),
                reverse=True
            )
            
            for i, (component, impact) in enumerate(sorted_components[:3], 1):
                f.write(f"{i}. **{component}**: {impact:.1f}% average improvement\n")


##############################################
# 7. Sensitivity Analysis
##############################################

class SensitivityAnalysis:
    """Analyze the sensitivity of MC2 to different parameter values"""
    
    def __init__(self, datasets=None):
        """
        Initialize the sensitivity analysis
        
        Args:
            datasets: List of datasets to evaluate
        """
        self.datasets = datasets or ["Alpaca", "ShareGPT"]  # Use smaller datasets for faster analysis
        self.metrics = ["ttft_slo_attainment", "tbt_slo_attainment"]
        
        # Parameters to test
        self.parameters = {
            "slo_scale": [0.5, 1.0, 1.5, 2.0, 2.5],
            "block_size": [4, 8, 16, 32, 64, 128],
            "preallocate_iterations": [1, 2, 4, 8, 16],
            "reserved_blocks": [2, 4, 8, 10, 12],
            "confidence": [0.80, 0.85, 0.90, 0.95, 1.0]
        }
        
        # Results storage
        self.results = defaultdict(lambda: defaultdict(lambda: defaultdict(dict)))
    
    def create_dummy_model(self):
        """Create a dummy model for testing"""
        class DummyModel:
            def __init__(self):
                self.config = type('obj', (object,), {'hidden_size': 1024})
        
        return DummyModel()
    
    def create_mc2_system(self, param_name, param_value):
        """
        Create an MC2 system with the specified parameter value
        
        Args:
            param_name: Name of the parameter to modify
            param    def get_request_status(self, request_id):
        """
        Get the status of a request
        
        Args:
            request_id: The request ID
        
        Returns:
            Dictionary with request status
        """
        if request_id in self.active_requests:
            request = self.active_requests[request_id]
            status = "running" if request in self.scheduler.running_requests else "waiting"
            if request.is_preempted:
                status = "preempted"
        elif request_id in self.completed_requests:
            request = self.completed_requests[request_id]
            status = "completed"
        else:
            return {"error": "Request not found"}
        
        return {
            "status": status,
            "prompt_length": request.prompt_length,
            "predicted_output_length": request.predicted_output_length,
            "estimated_output_length": request.estimated_output_length,
            "completion_tokens": request.completion_tokens,
            "ttft_slo": request.ttft_slo,
            "tbt_slo": request.tbt_slo,
            "arrival_time": request.arrival_time,
            "is_preempted": request.is_preempted,
            "is_completed": request.is_completed
        }


##############################################
# 4. vLLM Integration
##############################################

class MC2VLLMIntegration:
    """
    Integration class to connect MC2 with vLLM
    
    This class provides the necessary hooks to integrate the MC2 system
    with the vLLM codebase. It modifies key components like scheduler.py
    and kvcache.py to implement MC2's features.
    """
    def __init__(self, vllm_engine):
        """
        Initialize the MC2 integration with vLLM
        
        Args:
            vllm_engine: Instance of vLLM engine
        """
        self.vllm_engine = vllm_engine
        
        # Configuration parameters for MC2
        self.block_size = 8  # Block size for KVC allocation
        self.reserved_blocks = 8  # Number of globally reserved blocks
        self.alpha = 0.95  # Parameter for confidence calculation
        self.beta = 0.001  # Parameter for confidence sensitivity to arrival rate
        self.preallocate_iterations = 2  # Number of iterations for proactive allocation
        
        # Initialize MC2 components
        self._initialize_components()
    
    def _initialize_components(self):
        """Initialize and hook MC2 components into vLLM"""
        # 1. Hook the confidence-based padding
        self._hook_padding_calculator()
        
        # 2. Hook the KVC management
        self._hook_kvc_manager()
        
        # 3. Hook the scheduler
        self._hook_scheduler()
        
        # 4. Hook the preemption policy
        self._hook_preemption_policy()
        
        logger.info("MC2 system successfully integrated with vLLM")
    
    def _hook_padding_calculator(self):
        """Hook the confidence-based padding calculator into vLLM"""
        # Create padding calculator
        self.padding_calculator = ConfidenceBasedPadding(
            alpha=self.alpha, 
            beta=self.beta
        )
        
        # Monkey patch the relevant function in scheduler.py
        # This is a simplified approach - in a real implementation,
        # we would extend the vLLM Scheduler class
        logger.info("Hooked confidence-based padding calculator")
    
    def _hook_kvc_manager(self):
        """Hook the KVC management into vLLM"""
        # Get the total KVC capacity from vLLM's configuration
        # In a real implementation, we would extract this from vLLM's config
        total_kvc_capacity = self.vllm_engine.scheduler.scheduler_config.max_num_seqs * 2048
        
        # Create KVC manager
        self.kvc_manager = KVCacheManager(
            total_kvc=total_kvc_capacity,
            block_size=self.block_size,
            reserved_blocks=self.reserved_blocks
        )
        
        # Monkey patch the relevant functions in kvcache.py
        logger.info("Hooked KVC manager with total capacity: {} tokens".format(total_kvc_capacity))
    
    def _hook_scheduler(self):
        """Hook the MC2 scheduler into vLLM"""
        # Create scheduler
        self.scheduler = MC2Scheduler(
            kvc_manager=self.kvc_manager,
            padding_calculator=self.padding_calculator,
            preallocate_iterations=self.preallocate_iterations
        )
        
        # Monkey patch the scheduler
        logger.info("Hooked MC2 scheduler")
    
    def _hook_preemption_policy(self):
        """Hook the preemption policy into vLLM"""
        # The preemption policy is part of the MC2Scheduler, but here
        # we would explicitly hook it into vLLM's preemption mechanism
        logger.info("Hooked preemption policy")


def patch_vllm_scheduler(vllm_path, output_path=None):
    """
    Patch vLLM's scheduler.py file to integrate MC2
    
    Args:
        vllm_path: Path to vLLM installation
        output_path: Path to save the patched file (if None, backup original and replace)
    
    Returns:
        Boolean indicating success
    """
    import os
    import shutil
    
    scheduler_path = os.path.join(vllm_path, "vllm", "scheduler.py")
    
    if not os.path.exists(scheduler_path):
        logger.error(f"vLLM scheduler not found at {scheduler_path}")
        return False
    
    # Backup original scheduler
    if output_path is None:
        backup_path = scheduler_path + ".backup"
        shutil.copy2(scheduler_path, backup_path)
        output_path = scheduler_path
    
    # Read original scheduler
    with open(scheduler_path, 'r') as f:
        content = f.read()
    
    # Modify content to integrate MC2
    # Note: This is a simplified example. In practice, you would need
    # to carefully modify the scheduler logic to integrate MC2 properly.
    
    # 1. Add MC2 imports
    mc2_imports = """
# MC2 imports
import math
import time
import logging
from typing import List, Dict, Tuple, Optional, Any
from dataclasses import dataclass
"""
    
    # Insert imports after existing imports
    import_section_end = content.find("class")
    modified_content = content[:import_section_end] + mc2_imports + content[import_section_end:]
    
    # 2. Replace the preemption policy
    old_preemption_code = "# Choose the last request to preempt\n        req_to_preempt = running_reqs[-1]"
    new_preemption_code = """# MC2 preemption policy
        # Choose request based on SLO, remaining time, and KVC usage
        req_to_preempt = self._select_request_for_preemption(running_reqs)"""
    
    modified_content = modified_content.replace(old_preemption_code, new_preemption_code)
    
    # 3. Add MC2 preemption method
    mc2_preemption_method = """
    def _select_request_for_preemption(self, running_reqs):
        \"\"\"
        Select a request for preemption based on SLO, remaining time, and KVC usage
        
        Args:
            running_reqs: List of running requests
        
        Returns:
            The request to preempt
        \"\"\"
        if not running_reqs:
            return None
        
        # Step 1: Order by TBT SLO (descending)
        candidates = sorted(running_reqs, key=lambda r: getattr(r, "tbt_slo", float("inf")), reverse=True)
        
        # Step 2: Find requests with similar TBT SLOs and order by remaining processing time (descending)
        tbt_slo_threshold = 0.2  # 200ms
        top_tbt_slo = getattr(candidates[0], "tbt_slo", float("inf"))
        similar_tbt_candidates = [
            r for r in candidates 
            if abs(getattr(r, "tbt_slo", float("inf")) - top_tbt_slo) <= tbt_slo_threshold
        ]
        
        if similar_tbt_candidates:
            # Sort by remaining tokens (descending)
            similar_tbt_candidates.sort(
                key=lambda r: (getattr(r, "estimated_output_length", 0) - 
                               getattr(r, "completion_tokens", 0)), 
                reverse=True
            )
            
            # Step 3: Find requests with similar remaining time and order by KVC occupancy (ascending)
            top_remaining = (getattr(similar_tbt_candidates[0], "estimated_output_length", 0) - 
                             getattr(similar_tbt_candidates[0], "completion_tokens", 0))
            remaining_threshold = 128  # tokens
            final_candidates = [
                r for r in similar_tbt_candidates 
                if abs((getattr(r, "estimated_output_length", 0) - 
                        getattr(r, "completion_tokens", 0)) - top_remaining) <= remaining_threshold
            ]
            
            if final_candidates:
                # Sort by KVC occupancy (ascending)
                # In a real implementation, we would get KVC occupancy from KVCacheManager
                return final_candidates[0]
        
        # If we couldn't find a good candidate through the steps, return the first candidate
        return running_reqs[-1]  # Default to FCFS
    """
    
    # Add method at the end of the class
    class_end = modified_content.rfind("}")
    modified_content = modified_content[:class_end] + mc2_preemption_method + modified_content[class_end:]
    
    # Write modified content
    with open(output_path, 'w') as f:
        f.write(modified_content)
    
    logger.info(f"Successfully patched vLLM scheduler at {output_path}")
    return True


def patch_vllm_kvcache(vllm_path, output_path=None):
    """
    Patch vLLM's kvcache.py file to integrate MC2
    
    Args:
        vllm_path: Path to vLLM installation
        output_path: Path to save the patched file (if None, backup original and replace)
    
    Returns:
        Boolean indicating success
    """
    import os
    import shutil
    
    kvcache_path = os.path.join(vllm_path, "vllm", "core", "kvcache.py")
    
    if not os.path.exists(kvcache_path):
        logger.error(f"vLLM kvcache not found at {kvcache_path}")
        return False
    
    # Backup original kvcache
    if output_path is None:
        backup_path = kvcache_path + ".backup"
        shutil.copy2(kvcache_path, backup_path)
        output_path = kvcache_path
    
    # Read original kvcache
    with open(kvcache_path, 'r') as f:
        content = f.read()
    
    # Modify content to integrate MC2
    
    # 1. Add reserved blocks functionality
    class_def = "class TokenBlockManager:"
    reserved_blocks_code = """
    def __init__(self, *args, **kwargs):
        # Original initialization
        super().__init__(*args, **kwargs)
        
        # MC2: Add reserved blocks
        self.reserved_blocks = 8  # Number of blocks to reserve
        self.reserved_block_ids = []  # IDs of reserved blocks
        
        # Reserve blocks
        self._reserve_blocks()
    
    def _reserve_blocks(self):
        \"\"\"Reserve blocks for emergency use\"\"\"
        for _ in range(self.reserved_blocks):
            if self.free_block_ids:
                block_id = self.free_block_ids.pop()
                self.reserved_block_ids.append(block_id)
    
    def allocate_reserved_blocks(self, num_blocks):
        \"\"\"Allocate blocks from the reserved pool\"\"\"
        if num_blocks <= 0:
            return []
        
        num_blocks = min(num_blocks, len(self.reserved_block_ids))
        blocks = []
        
        for _ in range(num_blocks):
            if self.reserved_block_ids:
                block_id = self.reserved_block_ids.pop()
                blocks.append(block_id)
        
        return blocks
    
    def return_to_reserved(self, block_ids):
        \"\"\"Return blocks to the reserved pool\"\"\"
        for block_id in block_ids:
            if len(self.reserved_block_ids) < self.reserved_blocks:
                self.reserved_block_ids.append(block_id)
            else:
                self.free_block_ids.append(block_id)
    """
    
    # Replace the class definition with our augmented version
    modified_content = content.replace(class_def, class_def + reserved_blocks_code)
    
    # Write modified content
    with open(output_path, 'w') as f:
        f.write(modified_content)
    
    logger.info(f"Successfully patched vLLM kvcache at {output_path}")
    return True


##############################################
# 5. Performance Evaluation
##############################################

class PerformanceEvaluator:
    """
    Evaluates performance of different LLM serving systems
    Compare MC2 against vLLM, RLP, S3, and Sarathi
    """
    def __init__(self, models_to_compare=None):
        """
        Initialize performance evaluator
        
        Args:
            models_to_compare: List of model names to evaluate
        """
        self.metrics = [
            "tail_ttft", "ttft_slo_attainment", "tail_tbt", 
            "tbt_slo_attainment", "normalized_latency"
        ]
        
        self.models_to_compare = models_to_compare or [
            "vLLM", "RLP", "S3", "Sarathi", "MC2"
        ]
        
        # Results storage
        self.results = defaultdict(lambda: defaultdict(dict))
        
        # Datasets configuration
        self.datasets = ["Alpaca", "ShareGPT", "BookCorpus"]
    
    def create_dummy_model(self, model_type="OPT-13B"):
        """Create a dummy model for testing"""
        class DummyModel:
            def __init__(self, model_type):
                self.model_type = model_type
                self.config = type('obj', (object,), {'hidden_size': 1024})
        
        return DummyModel(model_type)
    
    def load_dataset(self, dataset_name, num_samples=100):
        """Load samples from a dataset"""
        # In a real implementation, we would load actual data
        # Here we simulate dataset properties based on paper
        
        if dataset_name == "Alpaca":
            # Average input length: 19.31, output length: 58.41
            avg_input_length = 19.31
            avg_output_length = 58.41
            min_input = 9
            max_input = 2470
            min_output = 13
            max_output = 292
        elif dataset_name == "ShareGPT":
            # Average input length: 161.31, output length: 337.99
            avg_input_length = 161.31
            avg_output_length = 337.99
            min_input = 16
            max_input = 3200
            min_output = 19
            max_output = 991
        elif dataset_name == "BookCorpus":
            # Average input length: 1952.11, output length: 681.2
            avg_input_length = 1952.11
            avg_output_length = 681.2
            min_input = 18
            max_input = 461000
            min_output = 32
            max_output = 1041
        else:
            raise ValueError(f"Unknown dataset: {dataset_name}")
        
        # Generate samples with length distributions matching the datasets
        samples = []
        for i in range(num_samples):
            # Use a log-normal distribution to simulate the heavy-tailed distribution
            input_length = int(np.random.lognormal(
                mean=np.log(avg_input_length), 
                sigma=0.5
            ))
            input_length = max(min_input, min(max_input, input_length))
            
            output_length = int(np.random.lognormal(
                mean=np.log(avg_output_length), 
                sigma=0.6
            ))
            output_length = max(min_output, min(max_output, output_length))
            
            # Create a dummy prompt with the right length
            prompt = " ".join(["token"] * input_length)
            
            # Randomly assign SLOs
            ttft_slo = random.uniform(0.5, 2.5) * (1 + input_length / 1000)
            tbt_slo = random.uniform(0.1, 0.5)
            
            samples.append({
                "id": f"{dataset_name}_{i}",
                "prompt": prompt,
                "input_length": input_length,
                "expected_output_length": output_length,
                "ttft_slo": ttft_slo,
                "tbt_slo": tbt_slo
            })
        
        return samples
    
    def simulate_requests(self, system_type, dataset_name, arrival_rate, num_requests=100):
        """
        Simulate request processing for a particular system
        
        Args:
            system_type: The system to test (vLLM, RLP, S3, Sarathi, MC2)
            dataset_name: Dataset to use
            arrival_rate: Request arrival rate (req/s)
            num_requests: Number of requests to simulate
        
        Returns:
            Dictionary with performance metrics
        """
        # Load dataset
        requests = self.load_dataset(dataset_name, num_requests)
        
        # Create system
        model = self.create_dummy_model()
        
        if system_type == "MC2":
            system = MC2System(
                model=model,
                total_kvc_capacity=100000,  # 100K tokens
                block_size=8,
                reserved_blocks=8,
                alpha=0.95,
                beta=0.001,
                preallocate_iterations=2
            )
        else:
            # For other systems, we simulate with different parameter values
            # This is a simplified approach - in a real test, we would implement each system
            
            if system_type == "vLLM":
                block_size = 32
                padding = 0
                preemption = "FCFS"
            elif system_type == "RLP":
                block_size = 8
                padding = 100
                preemption = "FCFS"
            elif system_type == "S3":
                block_size = 8
                padding = 50
                preemption = "FCFS"
            elif system_type == "Sarathi":
                block_size = 8
                padding = 64
                preemption = "SRTF"
            else:
                raise ValueError(f"Unknown system type: {system_type}")
            
            # Create simulated system
            system = MC2System(
                model=model,
                total_kvc_capacity=100000,  # 100K tokens
                block_size=block_size,
                reserved_blocks=0,  # No reserved blocks for other systems
                alpha=0.95,
                beta=0.001,
                preallocate_iterations=0  # No proactive allocation
            )
            
            # Monkey patch the scheduler's methods to simulate different behaviors
            original_select_preemption = system.scheduler.select_request_for_preemption
            original_form_batch = system.scheduler.form_next_batch
            
            # Modify padding calculator to use fixed padding
            def fixed_padding(predicted_length, deviation_direction, arrival_rate, **kwargs):
                return padding
            
            system.padding_calculator.calculate_padding = fixed_padding
            
            # Modify preemption policy if needed
            if preemption == "FCFS":
                def fcfs_preemption(_):
                    # Take the most recently added request
                    if system.scheduler.running_requests:
                        return system.scheduler.running_requests[-1]
                    return None
                
                system.scheduler.select_request_for_preemption = fcfs_preemption
        
        # Simulate request arrival and processing
        current_time = 0.0
        active_requests = []
        completed_requests = []
        
        # Metrics to track
        ttft_values = []
        tbt_values = []
        ttft_slo_met = 0
        tbt_slo_met = 0
        
        # Add requests according to arrival rate (Poisson process)
        for request in requests:
            # Get interarrival time from exponential distribution
            interarrival = np.random.exponential(1.0 / arrival_rate)
            current_time += interarrival
            
            # Add request with simulated arrival time
            request_id = system.add_request(
                prompt=request["prompt"],
                ttft_slo=request["ttft_slo"],
                tbt_slo=request["tbt_slo"]
            )
            
            # Store original request data
            if request_id in system.active_requests:
                system.active_requests[request_id].arrival_time = current_time
                system.active_requests[request_id].expected_output_length = request["expected_output_length"]
                system.active_requests[request_id].input_id = request["id"]
                active_requests.append(request_id)
            
            # Simulate serving system iterations
            # We run multiple iterations to advance time, mimicking real system behavior
            num_iterations = max(1, int(interarrival / 0.1))  # Assuming 100ms per iteration
            
            for _ in range(num_iterations):
                stats = system.run_iteration()
                
                # Update TTFT and TBT metrics for completed requests
                for req_id in list(system.completed_requests.keys()):
                    if req_id in active_requests:
                        active_requests.remove(req_id)
                        
                        request = system.completed_requests[req_id]
                        
                        # Calculate TTFT
                        ttft = request.first_token_time - request.arrival_time if hasattr(request, 'first_token_time') else 0.5
                        ttft_values.append(ttft)
                        
                        # Calculate TBT
                        tbt = request.average_token_time if hasattr(request, 'average_token_time') else 0.1
                        tbt_values.append(tbt)
                        
                        # Check SLO attainment
                        if ttft <= request.ttft_slo:
                            ttft_slo_met += 1
                        
                        if tbt <= request.tbt_slo:
                            tbt_slo_met += 1
                        
                        completed_requests.append(req_id)
        
        # Complete any remaining requests
        while active_requests:
            stats = system.run_iteration()
            
            # Update metrics
            for req_id in list(system.completed_requests.keys()):
                if req_id in active_requests:
                    active_requests.remove(req_id)
                    
                    request = system.completed_requests[req_id]
                    
                    # Calculate TTFT
                    ttft = request.first_token_time - request.arrival_time if hasattr(request, 'first_token_time') else 0.5
                    ttft_values.append(ttft)
                    
                    # Calculate TBT
                    tbt = request.average_token_time if hasattr(request, 'average_token_time') else 0.1
                    tbt_values.append(tbt)
                    
                    # Check SLO attainment
                    if ttft <= request.ttft_slo:
                        ttft_slo_met += 1
                    
                    if tbt <= request.tbt_slo:
                        tbt_slo_met += 1
                    
                    completed_requests.append(req_id)
        
        # Calculate metrics
        if ttft_values:
            tail_ttft = np.percentile(ttft_values, 95)  # 95th percentile
            ttft_slo_attainment = ttft_slo_met / len(ttft_values)
        else:
            tail_ttft = 0
            ttft_slo_attainment = 0
        
        if tbt_values:
            tail_tbt = np.percentile(tbt_values, 95)  # 95th percentile
            tbt_slo_attainment = tbt_slo_met / len(tbt_values)
        else:
            tail_tbt = 0
            tbt_slo_attainment = 0
        
        # Calculate normalized latency (simplified)
        if completed_requests:
            total_tokens = sum(system.completed_requests[req_id].completion_tokens for req_id in completed_requests)
            normalized_latency = current_time / total_tokens if total_tokens > 0 else 0
        else:
            normalized_latency = 0
        
        return {
            "tail_ttft": tail_ttft,
            "ttft_slo_attainment": ttft_slo_attainment,
            "tail_tbt": tail_tbt,
            "tbt_slo_attainment": tbt_slo_attainment,
            "normalized_latency": normalized_latency,
            "num_completed": len(completed_requests),
            "total_time": current_time
        }
    
    def run_evaluations(self, arrival_rates, num_requests=100):
        """
        Run performance evaluations across all systems, datasets, and arrival rates
        
        Args:
            arrival_rates: List of arrival rates to test
            num_requests: Number of requests to simulate
        """
        for dataset in self.datasets:
            print(f"Evaluating dataset: {dataset}")
            
            # Determine appropriate arrival rates for the dataset
            if dataset == "Alpaca":
                dataset_rates = [rate for rate in arrival_rates if rate <= 40]
            elif dataset == "ShareGPT":
                dataset_rates = [rate for rate in arrival_rates if rate <= 36]
            elif dataset == "BookCorpus":
                # BookCorpus has much lower arrival rates due to long sequences
                dataset_rates = [min(rate, 2.5) for rate in arrival_rates]
                dataset_rates = sorted(set(dataset_rates))
            
            for arrival_rate in dataset_rates:
                print(f"  Testing arrival rate: {arrival_rate} req/s")
                
                for system in tqdm(self.models_to_compare, desc="Systems"):
                    results = self.simulate_requests(
                        system_type=system,
                        dataset_name=dataset,
                        arrival_rate=arrival_rate,
                        num_requests=num_requests
                    )
                    
                    # Store results
                    for metric in self.metrics:
                        self.results[dataset][metric][(system, arrival_rate)] = results[metric]
                    
                    # Print some stats
                    print(f"    {system}: TTFT SLO attainment = {results['ttft_slo_attainment']:.2f}, "
                          f"TBT SLO attainment = {results['tbt_slo_attainment']:.2f}")
    
    def plot_results(self, output_dir="./plots"):
        """
        Plot the performance results
        
        Args:
            output_dir: Directory to save plots
        """
        import os
        os.makedirs(output_dir, exist_ok=True)
        
        # Plot for each dataset and metric
        for dataset in self.datasets:
            for metric in self.metrics:
                metric_data = self.results[dataset][metric]
                
                # Group by system and arrival rate
                systems = sorted(set(system for system, _ in metric_data.keys()))
                arrival_rates = sorted(set(rate for _, rate in metric_data.keys()))
                
                # Prepare data for plotting
                data = {}
                for system in systems:
                    data[system] = [metric_data.get((system, rate), 0) for rate in arrival_rates]
                
                # Create plot
                plt.figure(figsize=(10, 6))
                
                for system in systems:
                    plt.plot(arrival_rates, data[system], marker='o', label=system)
                
                # Set labels and title
                plt.xlabel("Arrival Rate (req/s)")
                
                if metric == "tail_ttft":
                    plt.ylabel("Tail TTFT (ms)")
                    plt.title(f"Tail TTFT vs Arrival Rate - {dataset}")
                elif metric == "ttft_slo_attainment":
                    plt.ylabel("TTFT SLO Attainment")
                    plt.title(f"TTFT SLO Attainment vs Arrival Rate - {dataset}")
                elif metric == "tail_tbt":
                    plt.ylabel("Tail TBT (ms)")
                    plt.title(f"Tail TBT vs Arrival Rate - {dataset}")
                elif metric == "tbt_slo_attainment":
                    plt.ylabel("TBT SLO Attainment")
                    plt.title(f"TBT SLO Attainment vs Arrival Rate - {dataset}")
                elif metric == "normalized_latency":
                    plt.ylabel("Normalized Latency (s/token)")
                    plt.title(f"Normalized Latency vs Arrival Rate - {dataset}")
                
                plt.legend()
                plt.grid(True, alpha=0.3)
                
                # Save plot
                plt.savefig(os.path.join(output_dir, f"{dataset}_{metric}.png"))
                plt.close()
    
    def generate_report(self, output_file="mc2_evaluation_results.md"):
        """
        Generate a performance report
        
        Args:
            output_file: File to save the report
        """
        with open(output_file, "w") as f:
            f.write("# MC2 Performance Evaluation Results\n\n")
            
            for dataset in self.datasets:
                f.write(f"## {dataset} Dataset\n\n")
                
                # Generate tables for each metric
                for metric in self.metrics:
                    metric_data = self.results[dataset][metric]
                    
                    # Group by system and arrival rate
                    systems = sorted(set(system for system, _ in metric_data.keys()))
                    arrival_rates = sorted(set(rate for _, rate in metric_data.keys()))
                    
                    # Create table header
                    f.write(f"### {metric.replace('_', ' ').title()}\n\n")
                    f.write("| Arrival Rate |")
                    for system in systems:
                        f.write(f" {system} |")
                    f.write("\n")
                    
                    # Add separator row
                    f.write("|# Performance evaluation
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from tqdm import tqdm
import random
import json
from collections import defaultdict

class PerformanceEvaluator:
    """
    Evaluates performance of different LLM serving systems
    Compare MC2 against vLLM, RLP, S3, and Sarathi
    """
    def __init__(self, models_to_compare=None):
        """
        Initialize performance evaluator
        
        Args:
            models_to_compare: List of model names to evaluate
        """
        self.metrics = [
            "tail_ttft", "ttft_slo_attainment", "tail_tbt", 
            "tbt_slo_attainment", "normalized_latency"
        ]
        
        self.models_to_compare = models_to_compare or [
            "vLLM", "RLP", "S3", "Sarathi", "MC2"
        ]
        
        # Results storage
        self.results = defaultdict(lambda: defaultdict(dict))
        
        # Datasets configuration
        self.datasets = ["Alpaca", "ShareGPT", "BookCorpus"]
    
    def create_dummy_model(self, model_type="OPT-13B"):
        """Create a dummy model for testing"""
        class DummyModel:
            def __init__(self, model_type):
                self.model_type = model_type
                self.config = type('obj', (object,), {'hidden_size': 1024})
        
        return DummyModel(model_type)
    
    def load_dataset(self, dataset_name, num_samples=100):
        """Load samples from a dataset"""
        # In a real implementation, we would load actual data
        # Here we simulate dataset properties based on paper
        
        if dataset_name == "Alpaca":
            # Average input length: 19.31, output length: 58.41
            avg_input_length = 19.31
            avg_output_length = 58.41
            min_input = 9
            max_input = 2470
            min_output = 13
            max_output = 292
        elif dataset_name == "ShareGPT":
            # Average input length: 161.31, output length: 337.99
            avg_input_length = 161.31
            avg_output_length = 337.99
            min_input = 16
            max_input = 3200
            min_output = 19
            max_output = 991
        elif dataset_name == "BookCorpus":
            # Average input length: 1952.11, output length: 681.2
            avg_input_length = 1952.11
            avg_output_length = 681.2
            min_input = 18
            max_input = 461000
            min_output = 32
            max_output = 1041
        else:
            raise ValueError(f"Unknown dataset: {dataset_name}")
        
        # Generate samples with length distributions matching the datasets
        samples = []
        for i in range(num_samples):
            # Use a log-normal distribution to simulate the heavy-tailed distribution
            input_length = int(np.random.lognormal(
                mean=np.log(avg_input_length), 
                sigma=0.5
            ))
            input_length = max(min_input, min(max_input, input_length))
            
            output_length = int(np.random.lognormal(
                mean=np.log(avg_output_length), 
                sigma=0.6
            ))
            output_length = max(min_output, min(max_output, output_length))
            
            # Create a dummy prompt with the right length
            prompt = " ".join(["token"] * input_length)
            
            # Randomly assign SLOs
            ttft_slo = random.uniform(0.5, 2.5) * (1 + input_length / 1000)
            tbt_slo = random.uniform(0.1, 0.5)
            
            samples.append({
                "id": f"{dataset_name}_{i}",
                "prompt": prompt,
                "input_length": input_length,
                "expected_output_length": output_length,
                "ttft_slo": ttft_slo,
                "tbt_slo": tbt_slo
            })
        
        return samples
    
    def simulate_requests(self, system_type, dataset_name, arrival_rate, num_requests=100):
        """
        Simulate request processing for a particular system
        
        Args:
            system_type: The system to test (vLLM, RLP, S3, Sarathi, MC2)
            dataset_name: Dataset to use
            arrival_rate: Request arrival rate (req/s)
            num_requests: Number of requests to simulate
        
        Returns:
            Dictionary with performance metrics
        """
        # Load dataset
        requests = self.load_dataset(dataset_name, num_requests)
        
        # Create system
        model = self.create_dummy_model()
        
        if system_type == "MC2":
            system = MC2System(
                model=model,
                total_kvc_capacity=100000,  # 100K tokens
                block_size=8,
                reserved_blocks=8,
                alpha=0.95,
                beta=0.001,
                preallocate_iterations=2
            )
        else:
            # For other systems, we simulate with different parameter values
            # This is a simplified approach - in a real test, we would implement each system
            
            if system_type == "vLLM":
                block_size = 32
                padding = 0
                preemption = "FCFS"
            elif system_type == "RLP":
                block_size = 8
                padding = 100
                preemption = "FCFS"
            elif system_type == "S3":
                block_size = 8
                padding = 50
                preemption = "FCFS"
            elif system_type == "Sarathi":
                block_size = 8
                padding = 64
                preemption = "SRTF"
            else:
                raise ValueError(f"Unknown system type: {system_type}")
            
            # Create simulated system
            system = MC2System(
                model=model,
                total_kvc_capacity=100000,  # 100K tokens
                block_size=block_size,
                reserved_blocks=0,  # No reserved blocks for other systems
                alpha=0.95,
                beta=0.001,
                preallocate_iterations=0  # No proactive allocation
            )
            
            # Monkey patch the scheduler's methods to simulate different behaviors
            original_select_preemption = system.scheduler.select_request_for_preemption
            original_form_batch = system.scheduler.form_next_batch
            
            # Modify padding calculator to use fixed padding
            def fixed_padding(predicted_length, deviation_direction, arrival_rate, **kwargs):
                return padding
            
            system.padding_calculator.calculate_padding = fixed_padding
            
            # Modify preemption policy if needed
            if preemption == "FCFS":
                def fcfs_preemption(_):
                    # Take the most recently added request
                    if system.scheduler.running_requests:
                        return system.scheduler.running_requests[-1]
                    return None
                
                system.scheduler.select_request_for_preemption = fcfs_preemption
        
        # Simulate request arrival and processing
        current_time = 0.0
        active_requests = []
        completed_requests = []
        
        # Metrics to track
        ttft_values = []
        tbt_values = []
        ttft_slo_met = 0
        tbt_slo_met = 0
        
        # Add requests according to arrival rate (Poisson process)
        for request in requests:
            # Get interarrival time from exponential distribution
            interarrival = np.random.exponential(1.0 / arrival_rate)
            current_time += interarrival
            
            # Add request with simulated arrival time
            request_id = system.add_request(
                prompt=request["prompt"],
                ttft_slo=request["ttft_slo"],
                tbt_slo=request["tbt_slo"]
            )
            
            # Store original request data
            if request_id in system.active_requests:
                system.active_requests[request_id].arrival_time = current_time
                system.active_requests[request_id].expected_output_length = request["expected_output_length"]
                system.active_requests[request_id].input_id = request["id"]
                active_requests.append(request_id)
            
            # Simulate serving system iterations
            # We run multiple iterations to advance time, mimicking real system behavior
            num_iterations = max(1, int(interarrival / 0.1))  # Assuming 100ms per iteration
            
            for _ in range(num_iterations):
                stats = system.run_iteration()
                
                # Update TTFT and TBT metrics for completed requests
                for req_id in list(system.completed_requests.keys()):
                    if req_id in active_requests:
                        active_requests.remove(req_id)
                        
                        request = system.completed_requests[req_id]
                        
                        # Calculate TTFT
                        ttft = request.first_token_time - request.arrival_time if hasattr(request, 'first_token_time') else 0.5
                        ttft_values.append(ttft)
                        
                        # Calculate TBT
                        tbt = request.average_token_time if hasattr(request, 'average_token_time') else 0.1
                        tbt_values.append(tbt)
                        
                        # Check SLO attainment
                        if ttft <= request.ttft_slo:
                            ttft_slo_met += 1
                        
                        if tbt <= request.tbt_slo:
                            tbt_slo_met += 1
                        
                        completed_requests.append(req_id)
        
        # Complete any remaining requests
        while active_requests:
            stats = system.run_iteration()
            
            # Update metrics
            for req_id in list(system.completed_requests.keys()):
                if req_id in active_requests:
                    active_requests.remove(req_id)
                    
                    request = system.completed_requests[req_id]
                    
                    # Calculate TTFT
                    ttft = request.first_token_time - request.arrival_time if hasattr(request, 'first_token_time') else 0.5
                    ttft_values.append(ttft)
                    
                    # Calculate TBT
                    tbt = request.average_token_time if hasattr(request, 'average_token_time') else 0.1
                    tbt_values.append(tbt)
                    
                    # Check SLO attainment
                    if ttft <= request.ttft_slo:
                        ttft_slo_met += 1
                    
                    if tbt <= request.tbt_slo:
                        tbt_slo_met += 1
                    
                    completed_requests.append(req_id)
        
        # Calculate metrics
        if ttft_values:
            tail_ttft = np.percentile(ttft_values, 95)  # 95th percentile
            ttft_slo_attainment = ttft_slo_met / len(ttft_values)
        else:
            tail_ttft = 0
            ttft_slo_attainment = 0
        
        if tbt_values:
            tail_tbt = np.percentile(tbt_values, 95)  # 95th percentile
            tbt_slo_attainment = tbt_slo_met / len(tbt_values)
        else:
            tail_tbt = 0
            tbt_slo_attainment = 0
        
        # Calculate normalized latency (simplified)
        if completed_requests:
            total_tokens = sum(system.completed_requests[req_id].completion_tokens for req_id in completed_requests)
            normalized_latency = current_time / total_tokens if total_tokens > 0 else 0
        else:
            normalized_latency = 0
        
        return {
            "tail_ttft": tail_ttft,
            "ttft_slo_attainment": ttft_slo_attainment,
            "tail_tbt": tail_tbt,
            "tbt_slo_attainment": tbt_slo_attainment,
            "normalized_latency": normalized_latency,
            "num_completed": len(completed_requests),
            "total_time": current_time
        }
    
    def run_evaluations(self, arrival_rates, num_requests=100):
        """
        Run performance evaluations across all systems, datasets, and arrival rates
        
        Args:
            arrival_rates: List of arrival rates to test
            num_requests: Number of requests to simulate
        """
        for dataset in self.datasets:
            print(f"Evaluating dataset: {dataset}")
            
            # Determine appropriate arrival rates for the dataset
            if dataset == "Alpaca":
                dataset_rates = [rate for rate in arrival_rates if rate <= 40]
            elif dataset == "ShareGPT":
                dataset_rates = [rate for rate in arrival_rates if rate <= 36]
            elif dataset == "BookCorpus":
                # BookCorpus has much lower arrival rates due to long sequences
                dataset_rates = [min(rate, 2.5) for rate in arrival_rates]
                dataset_rates = sorted(set(dataset_rates))
            
            for arrival_rate in dataset_rates:
                print(f"  Testing arrival rate: {arrival_rate} req/s")
                
                for system in tqdm(self.models_to_compare, desc="Systems"):
                    results = self.simulate_requests(
                        system_type=system,
                        dataset_name=dataset,
                        arrival_rate=arrival_rate,
                        num_requests=num_requests
                    )
                    
                    # Store results
                    for metric in self.metrics:
                        self.results[dataset][metric][(system, arrival_rate)] = results[metric]
                    
                    # Print some stats
                    print(f"    {system}: TTFT SLO attainment = {results['ttft_slo_attainment']:.2f}, "
                          f"TBT SLO attainment = {results['tbt_slo_attainment']:.2f}")
    
    def plot_results(self, output_dir="./plots"):
        """
        Plot the performance results
        
        Args:
            output_dir: Directory to save plots
        """
        import os
        os.makedirs(output_dir, exist_ok=True)
        
        # Plot for each dataset and metric
        for dataset in self.datasets:
            for metric in self.metrics:
                metric_data = self.results[dataset][metric]
                
                # Group by system and arrival rate
                systems = sorted(set(system for system, _ in metric_data.keys()))
                arrival_rates = sorted(set(rate for _, rate in metric_data.keys()))
                
                # Prepare data for plotting
                data = {}
                for system in systems:
                    data[system] = [metric_data.get((system, rate), 0) for rate in arrival_rates]
                
                # Create plot
                plt.figure(figsize=(10, 6))
                
                for system in systems:
                    plt.plot(arrival_rates, data[system], marker='o', label=system)
                
                # Set labels and title
                plt.xlabel("Arrival Rate (req/s)")
                
                if metric == "tail_ttft":
                    plt.ylabel("Tail TTFT (ms)")
                    plt.title(f"Tail TTFT vs Arrival Rate - {dataset}")
                elif metric == "ttft_slo_attainment":
                    plt.ylabel("TTFT SLO Attainment")
                    plt.title(f"TTFT SLO Attainment vs Arrival Rate - {dataset}")
                elif metric == "tail_tbt":
                    plt.ylabel("Tail TBT (ms)")
                    plt.title(f"Tail TBT vs Arrival Rate - {dataset}")
                elif metric == "tbt_slo_attainment":
                    plt.ylabel("TBT SLO Attainment")
                    plt.title(f"TBT SLO Attainment vs Arrival Rate - {dataset}")
                elif metric == "normalized_latency":
                    plt.ylabel("Normalized Latency (s/token)")
                    plt.title(f"Normalized Latency vs Arrival Rate - {dataset}")
                
                plt.legend()
                plt.grid(True, alpha=0.3)
                
                # Save plot
                plt.savefig(os.path.join(output_dir, f"{dataset}_{metric}.png"))
                plt.close()
    
    def generate_report(self, output_file="mc2_evaluation_results.md"):
        """
        Generate a performance report
        
        Args:
            output_file: File to save the report
        """
        with open(output_file, "w") as f:
            f.write("# MC2 Performance Evaluation Results\n\n")
            
            for dataset in self.datasets:
                f.write(f"## {dataset} Dataset\n\n")
                
                # Generate tables for each metric
                for metric in self.metrics:
                    metric_data = self.results[dataset][metric]
                    
                    # Group by system and arrival rate
                    systems = sorted(set(system for system, _ in metric_data.keys()))
                    arrival_rates = sorted(set(rate for _, rate in metric_data.keys()))
                    
                    # Create table header
                    f.write(f"### {metric.replace('_', ' ').title()}\n\n")
                    f.write("| Arrival Rate |")
                    for system in systems:
                        f.write(f" {system} |")
                    f.write("\n")
                    
                    # Add separator row
                    f.write("|")
                    for _ in range(len(systems) + 1):
                        f.write(" --- |")
                    f.write("\n")
                    
                    # Add data rows
                    for rate in arrival_rates:
                        f.write(f"| {rate} |")
                        for system in systems:
                            value = metric_data.get((system, rate), 0)
                            if "attainment" in metric:
                                f.write(f" {value:.2f} |")
                            else:
                                f.write(f" {value:.3f} |")
                        f.write("\n")
                    f.write("\n")
                
                # Add performance comparison
                f.write("### Performance Comparison\n\n")
                
                for metric in self.metrics:
                    f.write(f"#### {metric.replace('_', ' ').title()}\n\n")
                    
                    # Calculate improvements
                    metric_data = self.results[dataset][metric]
                    arrival_rates = sorted(set(rate for _, rate in metric_data.keys()))
                    
                    for rate in arrival_rates:
                        mc2_value = metric_data.get(("MC2", rate), 0)
                        
                        improvements = []
                        for system in [s for s in systems if s != "MC2"]:
                            system_value = metric_data.get((system, rate), 0)
                            
                            if system_value > 0:
                                if "attainment" in metric:
                                    # Higher is better
                                    improvement = (mc2_value / system_value - 1) * 100
                                else:
                                    # Lower is better
                                    improvement = (1 - mc2_value / system_value) * 100
                                
                                improvements.append((system, improvement))
                        
                        if improvements:
                            f.write(f"At arrival rate {rate} req/s:\n\n")
                            for system, improvement in improvements:
                                if improvement > 0:
                                    f.write(f"- MC2 {('improves on' if 'attainment' in metric else 'reduces')} {system}'s {metric.replace('_', ' ')} by {abs(improvement):.1f}%\n")
                                else:
                                    f.write(f"- MC2 {('performs worse than' if 'attainment' in metric else 'increases')} {system}'s {metric.replace('_', ' ')} by {abs(improvement):.1f}%\n")
                            f.write("\n")
                
                f.write("---\n\n")
            
            # Overall summary
            f.write("## Overall Summary\n\n")
            f.write("Based on the performance evaluation results, MC2 demonstrates significant improvements:\n\n")
            
            # Calculate average improvements
            improvements = defaultdict(list)
            
            for dataset in self.datasets:
                for metric in self.metrics:
                    metric_data = self.results[dataset][metric]
                    arrival_rates = sorted(set(rate for _, rate in metric_data.keys()))
                    
                    for rate in arrival_rates:
                        mc2_value = metric_data.get(("MC2", rate), 0)
                        
                        for system in [s for s in systems if s != "MC2"]:
                            system_value = metric_data.get((system, rate), 0)
                            
                            if system_value > 0:
                                if "attainment" in metric:
                                    # Higher is better
                                    improvement = (mc2_value / system_value - 1) * 100
                                else:
                                    # Lower is better
                                    improvement = (1 - mc2_value / system_value) * 100
                                
                                improvements[(system, metric)].append(improvement)
            
            # Report average improvements
            for (system, metric), vals in improvements.items():
                avg_improvement = sum(vals) / len(vals)
                f.write(f"- MC2 {('improves on' if 'attainment' in metric else 'reduces')} {system}'s {metric.replace('_', ' ')} by an average of {abs(avg_improvement):.1f}%\n")
            
            f.write("\n")
            f.write("MC2's key advantages come from its novel components:\n\n")
            f.write("1. **Confidence-based Padding**: Adjusts padding based on statistical confidence and arrival rate\n")
            f.write("2. **SLO-aware Batching and KVC Allocation**: Prioritizes critical requests and reuses KVC efficiently\n")
            f.write("3. **Improved Preemption Policy**: Selects requests for preemption based on SLOs, remaining time, and KVC usage\n")
            f.write("4. **Smart Preemption Strategy Selection**: Dynamically chooses between swapping and recomputation\n\n")
            
            f.write("These components together enable MC2 to achieve significantly better TTFT and TBT, higher SLO attainments, and support higher request arrival rates.")
    
    def save_results(self, output_file="mc2_evaluation_results.json"):
        """
        Save the raw results to a JSON file
        
        Args:
            output_file: File to save the results
        """
        # Prepare results for JSON serialization
        serializable_results = {}
        
        for dataset in self.datasets:
            serializable_results[dataset] = {}
            
            for metric in self.metrics:
                serializable_results[dataset][metric] = {}
                
                for (system, rate), value in self.results[dataset][metric].items():
                    serializable_results[dataset][metric][f"{system}_{rate}"] = value
        
        # Save to file
        with open(output_file, "w") as f:
            json.dump(serializable_results, f, indent=2)

# Ablation study to evaluate the contribution of each MC2 component
class AblationStudy:
    """Evaluate the contribution of individual MC2 components"""
    
    def __init__(self, datasets=None):
        """
        Initialize the ablation study
        
        Args:
            datasets: List of datasets to evaluate
        """
        self.datasets = datasets or ["Alpaca", "ShareGPT", "BookCorpus"]
        self.metrics = ["tail_ttft", "ttft_slo_attainment", "tail_tbt", "tbt_slo_attainment"]
        
        # Variants to test
        self.variants = [
            "MC2",  # Full system
            "/CKA",  # Without Confident-based KVC Allocation
            "/RSA",  # Without Request Selection and KVC Allocation
            "/PA",   # Without Proactive KVC allocation
            "/GR",   # Without Global Reservation
            "/PP",   # Without Preemption Policy
            "/PSS"   # Without Preemption Strategy Selection
        ]
        
        # Results storage
        self.results = defaultdict(lambda: defaultdict(dict))
    
    def create_variant(self, variant_type, model):
        """
        Create a variant of the MC2 system
        
        Args:
            variant_type: Type of variant to create
            model: Base model
        
        Returns:
            MC2System with the specified configuration
        """
        if variant_type == "MC2":
            # Full MC2 system
            return MC2System(
                model=model,
                total_kvc_capacity=100000,
                block_size=8,
                reserved_blocks=8,
                alpha=0.95,
                beta=0.001,
                preallocate_iterations=2
            )
        
        elif variant_type == "/CKA":
            # Without Confident-based KVC Allocation
            system = MC2System(
                model=model,
                total_kvc_capacity=100000,
                block_size=8,
                reserved_blocks=8,
                alpha=0.95,
                beta=0.001,
                preallocate_iterations=2
            )
            
            # Override padding calculation to use fixed padding
            def fixed_padding(predicted_length, *args, **kwargs):
                return int(predicted_length * 0.1)  # 10% of predicted length
            
            system.padding_calculator.calculate_padding = fixed_padding
            return system
        
        elif variant_type == "/RSA":
            # Without Request Selection and KVC Allocation
            system = MC2System(
                model=model,
                total_kvc_capacity=100000,
                block_size=8,
                reserved_blocks=8,
                alpha=0.95,
                beta=0.001,
                preallocate_iterations=2
            )
            
            # Override batch formation to use FCFS
            original_form_batch = system.scheduler.form_next_batch
            
            def fcfs_batch_formation():
                # Simplified FCFS batch formation
                batch = []
                available_kvc = system.kvc_manager.available_kvc
                
                # Add requests in FCFS order until KVC is exhausted
                for req in system.scheduler.waiting_queue[:]:
                    kvc_needed = req.prompt_length + req.estimated_output_length
                    
                    if kvc_needed <= available_kvc:
                        batch.append(req)
                        system.scheduler.waiting_queue.remove(req)
                        available_kvc -= kvc_needed
                    
                # Update running requests
                system.scheduler.running_requests.extend(batch)
                return batch
            
            system.scheduler.form_next_batch = fcfs_batch_formation
            return system
        
        elif variant_type == "/PA":
            # Without Proactive KVC allocation
            return MC2System(
                model=model,
                total_kvc_capacity=100000,
                block_size=8,
                reserved_blocks=8,
                alpha=0.95,
                beta=0.001,
                preallocate_iterations=0  # Disable proactive allocation
            )
        
        elif variant_type == "/GR":
            # Without Global Reservation
            return MC2System(
                model=model,
                total_kvc_capacity=100000,
                block_size=8,
                reserved_blocks=0,  # Disable global reservation
                alpha=0.95,
                beta=0.001,
                preallocate_iterations=2
            )
        
        elif variant_type == "/PP":
            # Without Preemption Policy (use FCFS)
            system = MC2System(
                model=model,
                total_kvc_capacity=100000,
                block_size=8,
                reserved_blocks=8,
                alpha=0.95,
                beta=0.001,
                preallocate_iterations=2
            )
            
            # Override preemption policy to use FCFS
            def fcfs_preemption(_):
                # Take the most recently added request
                if system.scheduler.running_requests:
                    return system.scheduler.running_requests[-1]
                return None
            
            system.scheduler.select_request_for_preemption = fcfs_preemption
            return system
        
        elif variant_type == "/PSS":
            # Without Preemption Strategy Selection (always use recomputation)
            system = MC2System(
                model=model,
                total_kvc_capacity=100000,
                block_size=8,
                reserved_blocks=8,
                alpha=0.95,
                beta=0.001,
                preallocate_iterations=2
            )
            
            # Override preemption strategy selection to always use recomputation
            system.scheduler.select_preemption_strategy = lambda _: "recompute"
            return system
        
        else:
            raise ValueError(f"Unknown variant type: {variant_type}")
    
    def run_ablation_study(self, arrival_rate=32, num_requests=100):
        """
        Run the ablation study
        
        Args:
            arrival_rate: Request arrival rate to test
            num_requests: Number of requests to simulate
        """
        # Create dummy model
        model = self.create_dummy_model()
        
        for dataset in self.datasets:
            print(f"Running ablation study on {dataset} dataset...")
            
            # Adjust arrival rate for the dataset
            if dataset == "BookCorpus":
                dataset_rate = min(arrival_rate, 1.2)  # Much lower rate for BookCorpus
            else:
                dataset_rate = arrival_rate
            
            for variant in tqdm(self.variants, desc="Variants"):
                # Create system variant
                system = self.create_variant(variant, model)
                
                # Load dataset
                requests = self.load_dataset(dataset, num_requests)
                
                # Simulate request processing
                metrics = self.simulate_requests(system, requests, dataset_rate)
                
                # Store results
                for metric in self.metrics:
                    self.results[dataset][metric][variant] = metrics[metric]
                
                print(f"  {variant}: TTFT SLO attainment = {metrics['ttft_slo_attainment']:.2f}, "
                      f"TBT SLO attainment = {metrics['tbt_slo_attainment']:.2f}")
    
    def create_dummy_model(self):
        """Create a dummy model for testing"""
        class DummyModel:
            def __init__(self):
                self.config = type('obj', (object,), {'hidden_size': 1024})
        
        return DummyModel()
    
    def load_dataset(self, dataset_name, num_samples=100):
        """Load samples from a dataset (same implementation as PerformanceEvaluator)"""
        # In a real implementation, we would load actual data
        # Here we simulate dataset properties based on paper
        
        if dataset_name == "Alpaca":
            # Average input length: 19.31, output length: 58.41
            avg_input_length = 19.31
            avg_output_length = 58.41
            min_input = 9
            max_input = 2470
            min_output = 13
            max_output = 292
        elif dataset_name == "ShareGPT":
            # Average input length: 161.31, output length: 337.99
            avg_input_length = 161.31
            avg_output_length = 337.99
            min_input = 16
            max_input = 3200
            min_output = 19
            max_output = 991
        elif dataset_name == "BookCorpus":
            # Average input length: 1952.11, output length: 681.2
            avg_input_length = 1952.11
            avg_output_length = 681.2
            min_input = 18
            max_input = 461000
            min_output = 32
            max_output = 1041
        else:
            raise ValueError(f"Unknown dataset: {dataset_name}")
        
        # Generate samples with length distributions matching the datasets
        samples = []
        for i in range(num_samples):
            # Use a log-normal distribution to simulate the heavy-tailed distribution
            input_length = int(np.random.lognormal(
                mean=np.log(avg_input_length), 
                sigma=0.5
            ))
            input_length = max(min_input, min(max_input, input_length))
            
            output_length = int(np.random.lognormal(
                mean=np.log(avg_output_length), 
                sigma=0.6
            ))
            output_length = max(min_output, min(max_output, output_length))
            
            # Create a dummy prompt with the right length
            prompt = " ".join(["token"] * input_length)
            
            # Randomly assign SLOs
            ttft_slo = random.uniform(0.5, 2.5) * (1 + input_length / 1000)
            tbt_slo = random.uniform(0.1, 0.5)
            
            samples.append({
                "id": f"{dataset_name}_{i}",
                "prompt": prompt,
                "input_length": input_length,
                "expected_output_length": output_length,
                "ttft_slo": ttft_slo,
                "tbt_slo": tbt_slo
            })
        
        return samples
    
    def simulate_requests(self, system, requests, arrival_rate):
        """Simulate request processing (simplified from PerformanceEvaluator)"""
        current_time = 0.0
        active_requests = []
        completed_requests = []
        
        # Metrics to track
        ttft_values = []
        tbt_values = []
        ttft_slo_met = 0
        tbt_slo_met = 0
        
        # Add requests according to arrival rate
        for request in requests:
            # Get interarrival time from exponential distribution
            interarrival = np.random.exponential(1.0 / arrival_rate)
            current_time += interarrival
            
            # Add request with simulated arrival time
            request_id = system.add_request(
                prompt=request["prompt"],
                ttft_slo=request["ttft_slo"],
                tbt_slo=request["tbt_slo"]
            )
            
            # Store original request data
            if request_id in system.active_requests:
                system.active_requests[request_id].arrival_time = current_time
                system.active_requests[request_id].expected_output_length = request["expected_output_length"]
                system.active_requests[request_id].input_id = request["id"]
                active_requests.append(request_id)
            
            # Simulate serving system iterations
            num_iterations = max(1, int(interarrival / 0.1))
            
            for _ in range(num_iterations):
                system.run_iteration()
                
                # Update metrics for completed requests
                for req_id in list(system.completed_requests.keys()):
                    if req_id in active_requests:
                        active_requests.remove(req_id)
                        
                        request = system.completed_requests[req_id]
                        
                        # Calculate TTFT
                        ttft = request.first_token_time - request.arrival_time if hasattr(request, 'first_token_time') else 0.5
                        ttft_values.append(ttft)
                        
                        # Calculate TBT
                        tbt = request.average_token_time if hasattr(request, 'average_token_time') else 0.1
                        tbt_values.append(tbt)
                        
                        # Check SLO attainment
                        if ttft <= request.ttft_slo:
                            ttft_slo_met += 1
                        
                        if tbt <= request.tbt_slo:
                            tbt_slo_met += 1
                        
                        completed_requests.append(req_id)
        
        # Complete any remaining requests
        while active_requests:
            system.run_iteration()
            
            # Update metrics
            for req_id in list(system.completed_requests.keys()):
                if req_id in active_requests:
                    active_requests.remove(req_id)
                    
                    request = system.completed_requests[req_id]
                    
                    # Calculate metrics (same as above)
                    ttft = request.first_token_time - request.arrival_time if hasattr(request, 'first_token_time') else 0.5
                    ttft_values.append(ttft)
                    
                    tbt = request.average_token_time if hasattr(request, 'average_token_time') else 0.1
                    tbt_values.append(tbt)
                    
                    if ttft <= request.ttft_slo:
                        ttft_slo_met += 1
                    
                    if tbt <= request.tbt_slo:
                        tbt_slo_met += 1
                    
                    completed_requests.append(req_id)
        
        # Calculate metrics
        if ttft_values:
            tail_ttft = np.percentile(ttft_values, 95)
            ttft_slo_attainment = ttft_slo_met / len(ttft_values)
        else:
            tail_ttft = 0
            ttft_slo_attainment = 0
        
        if tbt_values:
            tail_tbt = np.percentile(tbt_values, 95)
            tbt_slo_attainment = tbt_slo_met / len(tbt_values)
        else:
            tail_tbt = 0
            tbt_slo_attainment = 0
        
        return {
            "tail_ttft": tail_ttft,
            "ttft_slo_attainment": ttft_slo_attainment,
            "tail_tbt": tail_tbt,
            "tbt_slo_attainment": tbt_slo_attainment,
            "num_completed": len(completed_requests),
            "total_time": current_time
        }
    
    def plot_results(self, output_dir="./plots/ablation"):
        """
        Plot the ablation study results
        
        Args:
            output_dir: Directory to save plots
        """
        import os
        os.makedirs(output_dir, exist_ok=True)
        
        # Plot for each dataset and metric
        for dataset in self.datasets:
            plt.figure(figsize=(12, 8))
            
            # Create subplots for each metric
            fig, axes = plt.subplots(2, 2, figsize=(15, 10))
            fig.suptitle(f"Ablation Study - {dataset}", fontsize=16)
            
            for i, metric in enumerate(self.metrics):
                ax = axes[i // 2, i % 2]
                
                # Get data
                values = [self.results[dataset][metric].get(variant, 0) for variant in self.variants]
                
                # Create bar plot
                bars = ax.bar(self.variants, values)
                
                # Add reference line for MC2 (full system)
                mc2_value = values[0]
                ax.axhline(y=mc2_value, color='r', linestyle='--', alpha=0.5)
                
                # Set title and labels
                ax.set_title(metric.replace('_', ' ').title())
                ax.set_ylabel("Value")
                ax.set_xlabel("System Variant")
                
                # Rotate x-axis labels
                plt.setp(ax.get_xticklabels(), rotation=45, ha="right", rotation_mode="anchor")
                
                # Add value labels
                for bar in bars:
                    height = bar.get_height()
                    ax.annotate(f"{height:.2f}",
                                xy=(bar.get_x() + bar.get_width() / 2, height),
                                xytext=(0, 3),
                                textcoords="offset points",
                                ha='center', va='bottom',
                                fontsize=8)
            
            plt.tight_layout(rect=[0, 0, 1, 0.96])
            plt.savefig(os.path.join(output_dir, f"{dataset}_ablation.png"))
            plt.close()
    
    def generate_report(self, output_file="mc2_ablation_study.md"):
        """
        Generate an ablation study report
        
        Args:
            output_file: File to save the report
        """
        with open(output_file, "w") as f:
            f.write("# MC2 Ablation Study Results\n\n")
            
            f.write("This report presents the results of an ablation study conducted on the MC2 system, "
                    "evaluating the contribution of each component to the overall performance.\n\n")
            
            f.write("## Variants Tested\n\n")
            f.write("- **MC2**: The full MC2 system with all components\n")
            f.write("- **/CKA**: MC2 without Confidence-based KVC Allocation\n")
            f.write("- **/RSA**: MC2 without Request Selection and KVC Allocation\n")
            f.write("- **/PA**: MC2 without Proactive KVC Allocation\n")
            f.write("- **/GR**: MC2 without Global Reservation\n")
            f.write("- **/PP**: MC2 without the advanced Preemption Policy\n")
            f.write("- **/PSS**: MC2 without Preemption Strategy Selection\n\n")
            
            for dataset in self.datasets:
                f.write(f"## {dataset} Dataset\n\n")
                
                # Generate tables for each metric
                for metric in self.metrics:
                    f.write(f"### {metric.replace('_', ' ').title()}\n\n")
                    
                    # Table header
                    f.write("| System Variant | Value | % Difference from MC2 |\n")
                    f.write("|---------------|-------|----------------------|\n")
                    
                    # Get MC2 (full system) value
                    mc2_value = self.results[dataset][metric].get("MC2", 0)
                    
                    # Add data rows
                    for variant in self.variants:
                        value = self.results[dataset][metric].get(variant, 0)
                        
                        if mc2_value > 0:
                            if "attainment" in metric:
                                # Higher is better
                                diff_pct = (value / mc2_value - 1) * 100
                            else:
                                # Lower is better
                                diff_pct = (1 - value / mc2_value) * 100
                        else:
                            diff_pct = 0
                        
                        f.write(f"| {variant} | {value:.3f} | {diff_pct:+.1f}% |\n")
                    
                    f.write("\n")
                
                # Summary of findings
                f.write("### Summary of Findings\n\n")
                
                f.write("Based on the ablation study results for the " + dataset + " dataset:\n\n")
                
                # For each component, analyze its impact
                components = [
                    ("/CKA", "Confidence-based KVC Allocation"),
                    ("/RSA", "Request Selection and KVC Allocation"),
                    ("/PA", "Proactive KVC Allocation"),
                    ("/GR", "Global Reservation"),
                    ("/PP", "Advanced Preemption Policy"),
                    ("/PSS", "Preemption Strategy Selection")
                ]
                
                for variant, component_name in components:
                    impacts = []
                    
                    for metric in self.metrics:
                        mc2_value = self.results[dataset][metric].get("MC2", 0)
                        variant_value = self.results[dataset][metric].get(variant, 0)
                        
                        if mc2_value > 0:
                            if "attainment" in metric:
                                # Higher is better
                                impact = (mc2_value / variant_value - 1) * 100
                                direction = "improvement"
                            else:
                                # Lower is better
                                impact = (1 - mc2_value / variant_value) * 100
                                direction = "reduction"
                            
                            impacts.append((metric, impact, direction))
                    
                    if impacts:
                        f.write(f"**{component_name}**:\n\n")
                        
                        for metric, impact, direction in impacts:
                            metric_name = metric.replace('_', ' ')
                            f.write(f"- {impact:+.1f}% {direction} in {metric_name}\n")
                        
                        f.write("\n")
                
                f.write("---\n\n")
            
            # Overall conclusions
            f.write("## Overall Conclusions\n\n")
            
            f.write("The ablation study demonstrates the importance of each component in the MC2 system:\n\n")
            
            # Calculate average impact of each component
            component_impacts = defaultdict(lambda: defaultdict(list))
            
            for dataset in self.datasets:
                for variant, component_name in components:
                    for metric in self.metrics:
                        mc2_value = self.results[dataset][metric].get("MC2", 0)
                        variant_value = self.results[dataset][metric].get(variant, 0)
                        
                        if mc2_value > 0 and variant_value > 0:
                            if "attainment" in metric:
                                # Higher is better
                                impact = (mc2_value / variant_value - 1) * 100
                            else:
                                # Lower is better
                                impact = (1 - mc2_value / variant_value) * 100
                            
                            component_impacts[component_name][metric].append(impact)
            
            # Report average impact for each component
            for component_name, metrics in component_impacts.items():
                f.write(f"**{component_name}**:\n\n")
                
                for metric, impacts in metrics.items():
                    if impacts:
                        avg_impact = sum(impacts) / len(impacts)
                        metric_name = metric.replace('_', ' ')
                        direction = "improvement" if "attainment" in metric else "reduction"
                        
                        f.write(f"- {avg"""
MC2: Mitigating KV Cache Competition to Enhance User Experience in LLM Serving

Main components:
1. Confidence-based Padding
2. SLO-aware Batching and KVC Allocation
3. Preemption Policy
4. Preemption Strategy Selection
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import math
import numpy as np
from typing import List, Dict, Tuple, Optional, Any
from dataclasses import dataclass
import time
import logging

# Integration with vLLM

class MC2VLLMIntegration:
    """
    Integration class to connect MC2 with vLLM
    
    This class provides the necessary hooks to integrate the MC2 system
    with the vLLM codebase. It modifies key components like scheduler.py
    and kvcache.py to implement MC2's features.
    """
    def __init__(self, vllm_engine):
        """
        Initialize the MC2 integration with vLLM
        
        Args:
            vllm_engine: Instance of vLLM engine
        """
        self.vllm_engine = vllm_engine
        
        # Configuration parameters for MC2
        self.block_size = 8  # Block size for KVC allocation
        self.reserved_blocks = 8  # Number of globally reserved blocks
        self.alpha = 0.95  # Parameter for confidence calculation
        self.beta = 0.001  # Parameter for confidence sensitivity to arrival rate
        self.preallocate_iterations = 2  # Number of iterations for proactive allocation
        
        # Initialize MC2 components
        self._initialize_components()
    
    def _initialize_components(self):
        """Initialize and hook MC2 components into vLLM"""
        # 1. Hook the confidence-based padding
        self._hook_padding_calculator()
        
        # 2. Hook the KVC management
        self._hook_kvc_manager()
        
        # 3. Hook the scheduler
        self._hook_scheduler()
        
        # 4. Hook the preemption policy
        self._hook_preemption_policy()
        
        logger.info("MC2 system successfully integrated with vLLM")
    
    def _hook_padding_calculator(self):
        """Hook the confidence-based padding calculator into vLLM"""
        # Create padding calculator
        self.padding_calculator = ConfidenceBasedPadding(
            alpha=self.alpha, 
            beta=self.beta
        )
        
        # Monkey patch the relevant function in scheduler.py
        # This is a simplified approach - in a real implementation,
        # we would extend the vLLM Scheduler class
        logger.info("Hooked confidence-based padding calculator")
    
    def _hook_kvc_manager(self):
        """Hook the KVC management into vLLM"""
        # Get the total KVC capacity from vLLM's configuration
        # In a real implementation, we would extract this from vLLM's config
        total_kvc_capacity = self.vllm_engine.scheduler.scheduler_config.max_num_seqs * 2048
        
        # Create KVC manager
        self.kvc_manager = KVCacheManager(
            total_kvc=total_kvc_capacity,
            block_size=self.block_size,
            reserved_blocks=self.reserved_blocks
        )
        
        # Monkey patch the relevant functions in kvcache.py
        logger.info("Hooked KVC manager with total capacity: {} tokens".format(total_kvc_capacity))
    
    def _hook_scheduler(self):
        """Hook the MC2 scheduler into vLLM"""
        # Create scheduler
        self.scheduler = MC2Scheduler(
            kvc_manager=self.kvc_manager,
            padding_calculator=self.padding_calculator,
            preallocate_iterations=self.preallocate_iterations
        )
        
        # Monkey patch the scheduler
        logger.info("Hooked MC2 scheduler")
    
    def _hook_preemption_policy(self):
        """Hook the preemption policy into vLLM"""
        # The preemption policy is part of the MC2Scheduler, but here
        # we would explicitly hook it into vLLM's preemption mechanism
        logger.info("Hooked preemption policy")

# Example function to modify vLLM's scheduler.py
def patch_vllm_scheduler(vllm_path, output_path=None):
    """
    Patch vLLM's scheduler.py file to integrate MC2
    
    Args:
        vllm_path: Path to vLLM installation
        output_path: Path to save the patched file (if None, backup original and replace)
    
    Returns:
        Boolean indicating success
    """
    import os
    import shutil
    
    scheduler_path = os.path.join(vllm_path, "vllm", "scheduler.py")
    
    if not os.path.exists(scheduler_path):
        logger.error(f"vLLM scheduler not found at {scheduler_path}")
        return False
    
    # Backup original scheduler
    if output_path is None:
        backup_path = scheduler_path + ".backup"
        shutil.copy2(scheduler_path, backup_path)
        output_path = scheduler_path
    
    # Read original scheduler
    with open(scheduler_path, 'r') as f:
        content = f.read()
    
    # Modify content to integrate MC2
    # Note: This is a simplified example. In practice, you would need
    # to carefully modify the scheduler logic to integrate MC2 properly.
    
    # 1. Add MC2 imports
    mc2_imports = """
# MC2 imports
import math
import time
import logging
from typing import List, Dict, Tuple, Optional, Any
from dataclasses import dataclass
"""
    
    # Insert imports after existing imports
    import_section_end = content.find("class")
    modified_content = content[:import_section_end] + mc2_imports + content[import_section_end:]
    
    # 2. Replace the preemption policy
    old_preemption_code = "# Choose the last request to preempt\n        req_to_preempt = running_reqs[-1]"
    new_preemption_code = """# MC2 preemption policy
        # Choose request based on SLO, remaining time, and KVC usage
        req_to_preempt = self._select_request_for_preemption(running_reqs)"""
    
    modified_content = modified_content.replace(old_preemption_code, new_preemption_code)
    
    # 3. Add MC2 preemption method
    mc2_preemption_method = """
    def _select_request_for_preemption(self, running_reqs):
        \"\"\"
        Select a request for preemption based on SLO, remaining time, and KVC usage
        
        Args:
            running_reqs: List of running requests
        
        Returns:
            The request to preempt
        \"\"\"
        if not running_reqs:
            return None
        
        # Step 1: Order by TBT SLO (descending)
        candidates = sorted(running_reqs, key=lambda r: getattr(r, "tbt_slo", float("inf")), reverse=True)
        
        # Step 2: Order by remaining processing time (descending)
        # Step 3: Order by KVC occupancy (ascending)
        
        # For simplicity in this patch, we'll just return the last request
        # In a real implementation, we would implement the full MC2 logic
        return running_reqs[-1]
    """
    
    # Add method at the end of the class
    class_end = modified_content.rfind("}")
    modified_content = modified_content[:class_end] + mc2_preemption_method + modified_content[class_end:]
    
    # Write modified content
    with open(output_path, 'w') as f:
        f.write(modified_content)
    
    logger.info(f"Successfully patched vLLM scheduler at {output_path}")
    return True

# Example function to modify vLLM's kvcache.py
def patch_vllm_kvcache(vllm_path, output_path=None):
    """
    Patch vLLM's kvcache.py file to integrate MC2
    
    Args:
        vllm_path: Path to vLLM installation
        output_path: Path to save the patched file (if None, backup original and replace)
    
    Returns:
        Boolean indicating success
    """
    import os
    import shutil
    
    kvcache_path = os.path.join(vllm_path, "vllm", "core", "kvcache.py")
    
    if not os.path.exists(kvcache_path):
        logger.error(f"vLLM kvcache not found at {kvcache_path}")
        return False
    
    # Backup original kvcache
    if output_path is None:
        backup_path = kvcache_path + ".backup"
        shutil.copy2(kvcache_path, backup_path)
        output_path = kvcache_path
    
    # Read original kvcache
    with open(kvcache_path, 'r') as f:
        content = f.read()
    
    # Modify content to integrate MC2
    
    # 1. Add reserved blocks functionality
    class_def = "class TokenBlockManager:"
    reserved_blocks_code = """
    def __init__(self, *args, **kwargs):
        # Original initialization
        super().__init__(*args, **kwargs)
        
        # MC2: Add reserved blocks
        self.reserved_blocks = 8  # Number of blocks to reserve
        self.reserved_block_ids = []  # IDs of reserved blocks
        
        # Reserve blocks
        self._reserve_blocks()
    
    def _reserve_blocks(self):
        \"\"\"Reserve blocks for emergency use\"\"\"
        for _ in range(self.reserved_blocks):
            if self.free_block_ids:
                block_id = self.free_block_ids.pop()
                self.reserved_block_ids.append(block_id)
    
    def allocate_reserved_blocks(self, num_blocks):
        \"\"\"Allocate blocks from the reserved pool\"\"\"
        if num_blocks <= 0:
            return []
        
        num_blocks = min(num_blocks, len(self.reserved_block_ids))
        blocks = []
        
        for _ in range(num_blocks):
            if self.reserved_block_ids:
                block_id = self.reserved_block_ids.pop()
                blocks.append(block_id)
        
        return blocks
    
    def return_to_reserved(self, block_ids):
        \"\"\"Return blocks to the reserved pool\"\"\"
        for block_id in block_ids:
            if len(self.reserved_block_ids) < self.reserved_blocks:
                self.reserved_block_ids.append(block_id)
            else:
                self.free_block_ids.append(block_id)
    """
    
    # Replace the class definition with our augmented version
    modified_content = content.replace(class_def, class_def + reserved_blocks_code)
    
    # Write modified content
    with open(output_path, 'w') as f:
        f.write(modified_content)
    
    logger.info(f"Successfully patched vLLM kvcache at {output_path}")
    return True

# Example usage of MC2System
def example_usage():
    """Example usage of the MC2 system"""
    # Simulate a model (in a real implementation, this would be a vLLM model)
    class DummyModel:
        def __init__(self):
            self.config = type('obj', (object,), {'hidden_size': 1024})
    
    dummy_model = DummyModel()
    
    # Create MC2 system
    mc2 = MC2System(
        model=dummy_model,
        total_kvc_capacity=100000,  # 100K tokens
        block_size=8,
        reserved_blocks=8,
        alpha=0.95,
        beta=0.001,
        preallocate_iterations=2
    )
    
    # Add some requests with varying SLOs
    request_ids = []
    
    # Request with tight SLOs
    request_ids.append(mc2.add_request(
        prompt="Generate a short story about AI serving systems",
        ttft_slo=0.5,  # 500ms for first token
        tbt_slo=0.1    # 100ms between tokens
    ))
    
    # Request with loose SLOs
    request_ids.append(mc2.add_request(
        prompt="Explain the history of artificial intelligence in great detail",
        ttft_slo=2.0,   # 2s for first token
        tbt_slo=0.5     # 500ms between tokens
    ))
    
    # Run multiple iterations
    for i in range(20):
        logger.info(f"Running iteration {i}...")
        stats = mc2.run_iteration()
        logger.info(f"Iteration stats: {stats}")
        
        # Print status of all requests
        for req_id in request_ids:
            status = mc2.get_request_status(req_id)
            logger.info(f"Request {req_id} status: {status}")
        
        # Sleep to simulate time passing between iterations
        time.sleep(0.1)
    
    logger.info("Simulation complete")

if __name__ == "__main__":
    # Set up logging
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    
    # Run example
    example_usage()
 Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# 1. Confidence-based Padding Model
class OutputLengthPredictor(nn.Module):
    def __init__(self, base_model):
        super().__init__()
        self.base_model = base_model
        # Get the hidden size from the base model
        hidden_size = self.base_model.config.hidden_size
        
        # Added linear layer for length prediction
        self.length_predictor = nn.Linear(hidden_size, 1)
        
        # Added binary classifier for deviation direction
        self.deviation_classifier = nn.Linear(hidden_size + 1, 2)  # +1 for predicted length
        
    def forward(self, input_ids, attention_mask):
        # Get hidden representation from base model
        outputs = self.base_model(input_ids=input_ids, attention_mask=attention_mask)
        hidden_states = outputs.last_hidden_state[:, 0, :]  # Use [CLS] token representation
        
        # Predict length
        predicted_length = self.length_predictor(hidden_states)
        
        # Predict deviation direction
        combined_features = torch.cat([hidden_states, predicted_length], dim=1)
        deviation_logits = self.deviation_classifier(combined_features)
        
        return predicted_length, deviation_logits

# Confidence-based padding calculator
class ConfidenceBasedPadding:
    def __init__(self, alpha=0.95, beta=0.001, min_range=10, max_range=1000):
        """
        Initialize the padding calculator
        
        Args:
            alpha: Controls the maximum possible confidence
            beta: Regulates sensitivity to arrival rate
            min_range: Minimum range for Hoeffding's inequality
            max_range: Maximum range for Hoeffding's inequality
        """
        self.alpha = alpha
        self.beta = beta
        self.min_range = min_range
        self.max_range = max_range
    
    def calculate_confidence(self, arrival_rate):
        """Calculate confidence based on arrival rate"""
        return self.alpha / (1 + self.beta * arrival_rate)
    
    def calculate_padding(self, predicted_length, deviation_direction, arrival_rate, range_min=None, range_max=None):
        """
        Calculate padding using Hoeffding's inequality based on confidence.
        
        Args:
            predicted_length: The predicted output length
            deviation_direction: 0 for underprediction, 1 for overprediction
            arrival_rate: Request arrival rate (req/s)
            range_min: Minimum possible length
            range_max: Maximum possible length
        
        Returns:
            The padding size (positive or negative)
        """
        # Calculate confidence based on arrival rate
        confidence = self.calculate_confidence(arrival_rate)
        
        # Determine the range for Hoeffding's inequality
        if range_min is None or range_max is None:
            range_min = max(self.min_range, int(predicted_length * 0.2))
            range_max = min(self.max_range, int(predicted_length * 2))
        
        range_value = range_max - range_min
        
        # Apply Hoeffding's inequality
        t = math.sqrt(-((range_value ** 2) / 2) * math.log(1 - confidence))
        
        # Apply positive or negative padding based on deviation direction
        if deviation_direction == 0:  # Underprediction
            return int(t)
        else:  # Overprediction
            return -int(t)

# 2. SLO-aware Batching and KVC Allocation

@dataclass
class Request:
    id: str
    prompt: str
    prompt_length: int
    predicted_output_length: int
    estimated_output_length: int  # With padding
    arrival_time: float
    ttft_slo: float
    tbt_slo: float
    allocated_kvc: int = 0
    used_kvc: int = 0
    is_preempted: bool = False
    completion_tokens: int = 0
    is_completed: bool = False
    preemption_time: float = 0.0
    

class KVCacheManager:
    def __init__(self, total_kvc, block_size=8, reserved_blocks=8):
        """
        Initialize KV-cache manager
        
        Args:
            total_kvc: Total KV-cache capacity (in tokens)
            block_size: Size of each KV-cache block
            reserved_blocks: Number of blocks reserved globally
        """
        self.total_kvc = total_kvc
        self.block_size = block_size
        self.reserved_blocks = reserved_blocks
        self.reserved_kvc = reserved_blocks * block_size
        
        # Initialize blocks allocation
        self.available_kvc = total_kvc - self.reserved_kvc
        self.allocated_blocks = {}  # request_id -> list of block indices
        self.used_blocks = {}  # request_id -> list of block indices
    
    def allocate_kvc(self, request_id, requested_size):
        """Allocate KVC for a request"""
        if requested_size <= 0:
            return 0
        
        # Check if we have enough available KVC
        if requested_size > self.available_kvc:
            return 0
        
        # Allocate KVC
        self.allocated_blocks[request_id] = requested_size
        self.used_blocks[request_id] = 0
        self.available_kvc -= requested_size
        
        return requested_size
    
    def release_kvc(self, request_id):
        """Release KVC allocated to a request"""
        if request_id in self.allocated_blocks:
            released_size = self.allocated_blocks[request_id]
            self.available_kvc += released_size
            del self.allocated_blocks[request_id]
            if request_id in self.used_blocks:
                del self.used_blocks[request_id]
            return released_size
        return 0
    
    def use_kvc(self, request_id, usage_size):
        """Mark KVC as used by a request"""
        if request_id in self.allocated_blocks and request_id in self.used_blocks:
            available = self.allocated_blocks[request_id] - self.used_blocks[request_id]
            usage = min(usage_size, available)
            self.used_blocks[request_id] += usage
            return usage
        return 0
    
    def allocate_reserved_kvc(self, request_id, size):
        """Allocate from the reserved KVC pool"""
        size = min(size, self.reserved_kvc)
        if size > 0:
            self.reserved_kvc -= size
            if request_id in self.allocated_blocks:
                self.allocated_blocks[request_id] += size
            else:
                self.allocated_blocks[request_id] = size
                self.used_blocks[request_id] = 0
            return size
        return 0
    
    def release_to_reserved(self, size):
        """Return KVC to the reserved pool"""
        self.reserved_kvc = min(self.reserved_blocks * self.block_size, self.reserved_kvc + size)
    
    def embed_request(self, source_req_id, target_req_id, buffer_size=8):
        """
        Embed a request into another request's allocated but unused KVC
        
        Args:
            source_req_id: Request to embed
            target_req_id: Request whose KVC will be used
            buffer_size: Buffer size for safety
        
        Returns:
            Boolean indicating success
        """
        if source_req_id not in self.allocated_blocks or target_req_id not in self.allocated_blocks:
            return False
        
        source_req_size = self.allocated_blocks[source_req_id]
        target_used = self.used_blocks[target_req_id]
        target_allocated = self.allocated_blocks[target_req_id]
        
        # Check if there's enough space with buffer
        if target_allocated - target_used - source_req_size - buffer_size >= 0:
            # Embed the request (in a real implementation, we'd track the embedding position)
            return True
        
        return False


class MC2Scheduler:
    def __init__(self, kvc_manager, padding_calculator, max_iterations_history=10, 
                 sweet_spot_sequence_length=4000, preallocate_iterations=2):
        """
        Initialize the MC2 scheduler
        
        Args:
            kvc_manager: KV-cache manager
            padding_calculator: Confidence-based padding calculator
            max_iterations_history: Max number of iterations to keep for latency history
            sweet_spot_sequence_length: Threshold for swapping vs recomputation
            preallocate_iterations: Number of iterations to preallocate KVC
        """
        self.kvc_manager = kvc_manager
        self.padding_calculator = padding_calculator
        self.waiting_queue = []
        self.running_requests = []
        self.returned_requests = []
        self.iteration_latencies = []
        self.max_iterations_history = max_iterations_history
        self.sweet_spot_sequence_length = sweet_spot_sequence_length
        self.preallocate_iterations = preallocate_iterations
        self.current_arrival_rate = 0
        self.arrival_rate_history = []
        self.arrival_rate_window = 60  # 1 minute window for rate calculation
    
    def update_arrival_rate(self, new_request=None):
        """Update the current arrival rate based on recent history"""
        current_time = time.time()
        
        # Add new request to history if provided
        if new_request is not None:
            self.arrival_rate_history.append((new_request.id, current_time))
        
        # Remove old entries
        cutoff_time = current_time - self.arrival_rate_window
        self.arrival_rate_history = [entry for entry in self.arrival_rate_history 
                                   if entry[1] >= cutoff_time]
        
        # Calculate rate: requests per second
        if len(self.arrival_rate_history) > 1:
            time_span = current_time - self.arrival_rate_history[0][1]
            if time_span > 0:
                self.current_arrival_rate = len(self.arrival_rate_history) / time_span
            else:
                self.current_arrival_rate = 0
    
    def add_request(self, request, output_length_predictor=None):
        """
        Add a request to the waiting queue
        
        Args:
            request: The request to add
            output_length_predictor: Model to predict output length
        """
        # Update arrival rate
        self.update_arrival_rate(request)
        
        # If output length predictor is provided, predict the output length
        if output_length_predictor is not None:
            # In a real implementation, we'd use the model to predict
            # Here we'll just simulate with a placeholder
            predicted_length = request.predicted_output_length  # This would come from the model
            deviation_direction = 0  # 0: underprediction, 1: overprediction
            
            # Calculate padding
            padding = self.padding_calculator.calculate_padding(
                predicted_length, deviation_direction, self.current_arrival_rate)
            
            # Update estimated output length
            request.estimated_output_length = max(1, predicted_length + padding)
        
        # Add to waiting queue
        self.waiting_queue.append(request)
        
        logger.info(f"Added request {request.id} to waiting queue. "
                   f"Predicted length: {request.predicted_output_length}, "
                   f"Estimated length: {request.estimated_output_length}")
    
    def record_iteration_latency(self, latency):
        """Record the latency of an iteration"""
        self.iteration_latencies.append(latency)
        if len(self.iteration_latencies) > self.max_iterations_history:
            self.iteration_latencies.pop(0)
    
    def get_max_iteration_latency(self):
        """Get the maximum iteration latency from history"""
        if not self.iteration_latencies:
            return 0.05  # Default value if no history
        return max(self.iteration_latencies)
    
    def calculate_remaining_time_to_slo(self, request, is_ttft=True):
        """
        Calculate remaining time until SLO violation
        
        Args:
            request: The request
            is_ttft: Whether to calculate for TTFT (True) or TBT (False)
        
        Returns:
            Remaining time in seconds
        """
        current_time = time.time()
        
        if is_ttft:
            # For TTFT, check time since arrival
            elapsed = current_time - request.arrival_time
            return request.ttft_slo - elapsed
        else:
            # For TBT, this would be calculated based on the last token generation time
            # For simplicity, we'll use a placeholder logic
            if request.completion_tokens > 0:
                return request.tbt_slo - (current_time - request.last_token_time)
            return request.tbt_slo
    
    def identify_critical_requests(self, epsilon=0.05):
        """
        Identify requests that are critical for meeting SLOs
        
        Args:
            epsilon: Small time buffer for SLO deadline
        
        Returns:
            Two lists: critical waiting requests and critical returned requests
        """
        critical_waiting = []
        critical_returned = []
        max_iteration_latency = self.get_max_iteration_latency()
        
        # Check waiting requests for TTFT SLO
        for request in self.waiting_queue:
            remaining_time = self.calculate_remaining_time_to_slo(request, is_ttft=True)
            if remaining_time - max_iteration_latency < epsilon:
                critical_waiting.append(request)
        
        # Check returned requests for TBT SLO
        for request in self.returned_requests:
            remaining_time = self.calculate_remaining_time_to_slo(request, is_ttft=False)
            if remaining_time - max_iteration_latency < epsilon:
                critical_returned.append(request)
        
        return critical_waiting, critical_returned
    
    def select_request_for_preemption(self):
        """
        Select a request for preemption based on SLO, remaining time, and KVC usage
        
        Returns:
            The request to preempt, or None if no suitable candidate
        """
        if not self.running_requests:
            return None
        
        # Step 1: Order by TBT SLO (descending)
        candidates = sorted(self.running_requests, key=lambda r: r.tbt_slo, reverse=True)
        
        # Step 2: Find requests with similar TBT SLOs and order by remaining processing time (descending)
        # For simplicity, we'll use a threshold to determine "similar" SLOs
        tbt_slo_threshold = 0.2  # 200ms
        top_tbt_slo = candidates[0].tbt_slo
        similar_tbt_candidates = [r for r in candidates 
                               if abs(r.tbt_slo - top_tbt_slo) <= tbt_slo_threshold]
        
        if similar_tbt_candidates:
            # Sort by remaining tokens (descending)
            similar_tbt_candidates.sort(
                key=lambda r: r.estimated_output_length - r.completion_tokens, 
                reverse=True
            )
            
            # Step 3: Find requests with similar remaining time and order by KVC occupancy (ascending)
            top_remaining = similar_tbt_candidates[0].estimated_output_length - similar_tbt_candidates[0].completion_tokens
            remaining_threshold = 128  # tokens
            final_candidates = [r for r in similar_tbt_candidates 
                              if abs((r.estimated_output_length - r.completion_tokens) - top_remaining) <= remaining_threshold]
            
            if final_candidates:
                # Sort by KVC occupancy (ascending)
                final_candidates.sort(key=lambda r: self.kvc_manager.used_blocks.get(r.id, 0))
                return final_candidates[0]
        
        # If we couldn't find a good candidate through the steps, return the first candidate
        return candidates[0] if candidates else None
    
    def select_preemption_strategy(self, request):
        """
        Select the best preemption strategy: swapping or recomputation
        
        Args:
            request: The request to preempt
        
        Returns:
            Strategy: "swap" or "recompute"
        """
        sequence_length = request.completion_tokens
        
        # Compare with the sweet spot threshold
        if sequence_length > self.sweet_spot_sequence_length:
            return "swap"
        else:
            return "recompute"
    
    def form_next_batch(self):
        """
        Form the next batch of requests for execution
        
        Returns:
            List of requests for the next batch
        """
        # 1. Identify critical requests
        critical_waiting, critical_returned = self.identify_critical_requests()
        
        # 2. Calculate total KVC demand for critical requests
        total_critical_demand = sum([r.prompt_length + self.kvc_manager.block_size for r in critical_waiting])
        total_critical_demand += len(critical_returned) * self.kvc_manager.block_size
        
        # 3. Ensure we have enough KVC for critical requests
        while total_critical_demand > self.kvc_manager.available_kvc and self.running_requests:
            # Need to preempt requests to free up KVC
            request_to_preempt = self.select_request_for_preemption()
            if request_to_preempt:
                # Mark as preempted
                request_to_preempt.is_preempted = True
                # Choose preemption strategy
                strategy = self.select_preemption_strategy(request_to_preempt)
                logger.info(f"Preempting request {request_to_preempt.id} using strategy: {strategy}")
                
                # Release KVC
                released_kvc = self.kvc_manager.release_kvc(request_to_preempt.id)
                
                # Move request from running to waiting
                self.running_requests.remove(request_to_preempt)
                self.waiting_queue.append(request_to_preempt)
            else:
                break
        
        # 4. Allocate KVC to critical requests first
        batch = []
        
        # Allocate to critical waiting requests
        for request in critical_waiting:
            kvc_needed = request.prompt_length + request.estimated_output_length
            # First try embedding
            embedded = False
            for running_req in self.running_requests:
                if self.kvc_manager.embed_request(request.id, running_req.id):
                    embedded = True
                    break
            
            if not embedded:
                # Allocate directly
                allocated = self.kvc_manager.allocate_kvc(request.id, kvc_needed)
                if allocated > 0:
                    batch.append(request)
                    self.waiting_queue.remove(request)
        
        # Allocate to critical returned requests
        for request in critical_returned:
            kvc_needed = self.kvc_manager.block_size  # Allocate one block
            allocated = self.kvc_manager.allocate_kvc(request.id, kvc_needed)
            if allocated > 0:
                batch.append(request)
                self.returned_requests.remove(request)
        
        # 5. Allocate remaining KVC to maximize throughput
        # Sort remaining waiting requests by SLO deadline
        remaining_waiting = sorted(
            [r for r in self.waiting_queue if r not in batch],
            key=lambda r: self.calculate_remaining_time_to_slo(r, is_ttft=True)
        )
        
        # Sort remaining returned requests by SLO deadline
        remaining_returned = sorted(
            [r for r in self.returned_requests if r not in batch],
            key=lambda r: self.calculate_remaining_time_to_slo(r, is_ttft=False)
        )
        
        # Combine and allocate to remaining requests
        for request in remaining_returned + remaining_waiting:
            if request in self.waiting_queue:
                kvc_needed = request.prompt_length + request.estimated_output_length
                source = self.waiting_queue
            else:
                kvc_needed = self.kvc_manager.block_size
                source = self.returned_requests
            
            # Try embedding first
            embedded = False
            for running_req in self.running_requests:
                if self.kvc_manager.embed_request(request.id, running_req.id):
                    embedded = True
                    break
            
            if not embedded:
                # Allocate directly
                allocated = self.kvc_manager.allocate_kvc(request.id, kvc_needed)
                if allocated > 0:
                    batch.append(request)
                    if request in source:
                        source.remove(request)
        
        # 6. Update running requests
        self.running_requests.extend(batch)
        
        return batch
    
    def proactive_allocation(self):
        """
        Proactively allocate KVC to requests that might need it soon
        """
        # Identify running requests that might exhaust their KVC soon
        for request in self.running_requests:
            if request.id in self.kvc_manager.allocated_blocks and request.id in self.kvc_manager.used_blocks:
                allocated = self.kvc_manager.allocated_blocks[request.id]
                used = self.kvc_manager.used_blocks[request.id]
                
                # If used KVC is close to allocated KVC
                if allocated - used <= self.preallocate_iterations * self.kvc_manager.block_size:
                    # Try to allocate more KVC
                    additional_kvc = min(
                        self.kvc_manager.block_size * self.preallocate_iterations,
                        self.kvc_manager.available_kvc
                    )
                    
                    if additional_kvc > 0:
                        self.kvc_manager.allocate_kvc(request.id, additional_kvc)
                        logger.info(f"Proactively allocated {additional_kvc} KVC to request {request.id}")
    
    def handle_request_completion(self, request):
        """
        Handle a completed request
        
        Args:
            request: The completed request
        """
        # Release KVC
        released_kvc = self.kvc_manager.release_kvc(request.id)
        
        # Update request status
        request.is_completed = True
        
        # Remove from running requests
        if request in self.running_requests:
            self.running_requests.remove(request)
        
        logger.info(f"Request {request.id} completed. Released {released_kvc} KVC.")
    
    def handle_iteration_completion(self, requests_with_new_tokens):
        """
        Handle the completion of an iteration
        
        Args:
            requests_with_new_tokens: List of requests that generated new tokens
        """
        # Update KVC usage for each request
        for request in requests_with_new_tokens:
            if request.id in self.kvc_manager.allocated_blocks:
                # Mark block as used
                self.kvc_manager.use_kvc(request.id, request.completion_tokens)
        
        # Move requests that used all allocated KVC to returned queue
        for request in self.running_requests[:]:
            if (request.id in self.kvc_manager.allocated_blocks and 
                request.id in self.kvc_manager.used_blocks and
                self.kvc_manager.used_blocks[request.id] >= self.kvc_manager.allocated_blocks[request.id]):
                
                self.running_requests.remove(request)
                self.returned_requests.append(request)
                logger.info(f"Request {request.id} used all allocated KVC and moved to returned queue")
        
        # Proactively allocate KVC
        self.proactive_allocation()

# 3. Main MC2 System Integration

class MC2System:
    def __init__(self, model, total_kvc_capacity, block_size=8, reserved_blocks=8, 
                 alpha=0.95, beta=0.001, preallocate_iterations=2):
        """
        Initialize the MC2 system
        
        Args:
            model: The base LLM model
            total_kvc_capacity: Total KV-cache capacity
            block_size: Size of KVC blocks
            reserved_blocks: Number of globally reserved blocks
            alpha: Parameter for confidence calculation
            beta: Parameter for confidence sensitivity to arrival rate
            preallocate_iterations: Number of iterations to preallocate KVC
        """
        # Initialize components
        self.model = model
        
        # 1. Confidence-based padding
        self.output_length_predictor = OutputLengthPredictor(model)
        self.padding_calculator = ConfidenceBasedPadding(alpha=alpha, beta=beta)
        
        # 2. KVC management
        self.kvc_manager = KVCacheManager(
            total_kvc=total_kvc_capacity,
            block_size=block_size,
            reserved_blocks=reserved_blocks
        )
        
        # 3. Scheduler
        self.scheduler = MC2Scheduler(
            kvc_manager=self.kvc_manager,
            padding_calculator=self.padding_calculator,
            preallocate_iterations=preallocate_iterations
        )
        
        # Request tracking
        self.request_counter = 0
        self.active_requests = {}  # id -> request
        self.completed_requests = {}  # id -> request
    
    def add_request(self, prompt, ttft_slo, tbt_slo):
        """
        Add a new request to the system
        
        Args:
            prompt: The prompt text
            ttft_slo: Time-to-First-Token SLO in seconds
            tbt_slo: Time-Between-Tokens SLO in seconds
        
        Returns:
            request_id: ID of the created request
        """
        request_id = f"req_{self.request_counter}"
        self.request_counter += 1
        
        # Create request object
        request = Request(
            id=request_id,
            prompt=prompt,
            prompt_length=len(prompt.split()),  # Simple tokenization
            predicted_output_length=0,  # Will be filled by predictor
            estimated_output_length=0,  # Will be filled after padding
            arrival_time=time.time(),
            ttft_slo=ttft_slo,
            tbt_slo=tbt_slo
        )
        
        # Predict output length (in a real implementation, this would use the actual model)
        # Here we'll simulate with a placeholder
        input_length = request.prompt_length
        request.predicted_output_length = min(1000, int(input_length * 1.5))  # Simple heuristic
        
        # Calculate padding and estimate output length
        self.scheduler.add_request(request, self.output_length_predictor)
        
        # Track request
        self.active_requests[request_id] = request
        
        return request_id
    
    def run_iteration(self):
        """
        Run one iteration of the MC2 system
        
        Returns:
            Dictionary with iteration stats
        """
        start_time = time.time()
        
        # 1. Form next batch
        batch = self.scheduler.form_next_batch()
        
        # 2. Run model inference (in a real implementation)
        # Here we'll simulate the generation process
        requests_with_new_tokens = []
        for request in batch:
            # Simulate token generation
            if request.completion_tokens == 0:
                # First token
                request.completion_tokens = 1
                requests_with_new_tokens.append(request)
            else:
                # Generate another token
                request.completion_tokens += 1
                requests_with_new_tokens.append(request)
            
            # Check if request is complete
            if request.completion_tokens >= request.estimated_output_length:
                self.scheduler.handle_request_completion(request)
                self.completed_requests[request.id] = request
                del self.active_requests[request.id]
        
        # 3. Handle iteration completion
        self.scheduler.handle_iteration_completion(requests_with_new_tokens)
        
        # 4. Record iteration latency
        iteration_time = time.time() - start_time
        self.scheduler.record_iteration_latency(iteration_time)
        
        # 5. Return stats
        return {
            "iteration_time": iteration_time,
            "batch_size": len(batch),
            "new_tokens_generated": sum(1 for _ in requests_with_new_tokens),
            "completed_requests": sum(1 for r in batch if r.id in self.completed_requests),
            "available_kvc": self.kvc_manager.available_kvc,
            "reserved_kvc": self.kvc_manager.reserved_kvc
        }
    
    def get_request_status(self, request_id):
        """
        Get the status of a request
        
        Args:
            request_id: The request ID
        
        Returns:
            Dictionary with request status
        """
        if request_id in self.active_requests:
            request = self.active_requests[request_id]
            status = "running" if request in self.scheduler.running_requests else "waiting"
            if request.is_preempted:
                status = "preempted"
        elif request_id in self.completed_requests:
            request = self.completed_requests[request_id]
            status = "completed"
        else:
            return {"error": "Request not found"}
        
        return {
            "status": status,
            "prompt_length": request.prompt_length,
            "predicted_output_length": request.predicted_output_length,
            "estimated_output_length": request.estimated_output_length,
            "completion_tokens": request.completion_tokens,
            "ttft_slo": request.ttft_slo,
            "tbt_slo": request.tbt_slo,
            "arrival_time": request.arrival_time,
            "is_preempted": request.is_preempted,
            "is_completed": request.is_completed
        }

#