#pragma once

#define VLLM_IMPLIES(p, q) (!(p) || (q))
